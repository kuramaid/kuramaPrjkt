// wrdstrip.js — strip WeAreDevs anti-tamper wrapper, extract original payload
// argv[2] = input  (obfuscated .lua)
// argv[3] = output (stripped .lua)
const fs = require("fs")
const path = require("path")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node wrdstrip.js <input> <output>")
    process.exit(1)
}

const { parse, defaultOptions } = require("../parsers/luaparse")
const beautify = require("../parsers/beautifier")

const src = fs.readFileSync(inp, "utf8")
let ast
try {
    ast = parse(src, { ...defaultOptions, luaVersion: "5.1", encodingMode: "x-user-defined" })
} catch (e) {
    console.error("ERR|parse failed: " + e.message)
    process.exit(1)
}

const body = ast.body

// ── helpers ──────────────────────────────────────────────────────────────────

function is(node, tmpl) {
    if (!node || !tmpl) return false
    for (const k in tmpl) {
        if (tmpl[k] === null) { if (node[k] != null) return false; continue }
        if (typeof tmpl[k] === "object") {
            if (!is(node[k], tmpl[k])) return false
        } else if (node[k] !== tmpl[k]) return false
    }
    return true
}

function walk(node, fn) {
    if (!node || typeof node !== "object") return
    fn(node)
    for (const k of Object.keys(node)) {
        const v = node[k]
        if (Array.isArray(v)) v.forEach(c => walk(c, fn))
        else if (v && typeof v === "object" && v.type) walk(v, fn)
    }
}

// ── Strategy 1: find  if #v6 == 0 then <PAYLOAD> end  inside a repeat/while loop ──
// WRD structure:
//   for k = 1, 256 do v6[k] = k end
//   while/repeat:
//     k = table.remove(v6, math.random(...))
//     r18[k] = string.char(k-1)
//     if #v6 == 0 then
//       <PAYLOAD>
//       return
//     end

function findPayloadInIfZeroLen(body) {
    for (const stat of body) {
        if (!stat) continue
        // ForNumericStatement wrapping the shuffle + payload
        if (stat.type === "ForNumericStatement" || stat.type === "WhileStatement" ||
            stat.type === "RepeatStatement" || stat.type === "DoStatement") {
            const inner = stat.body || []
            const found = scanBodyForZeroLenIf(inner)
            if (found) return found
        }
        // Also check top-level IfStatement: if r1 then ... end
        if (stat.type === "IfStatement") {
            for (const clause of stat.clauses) {
                const found = scanBodyForZeroLenIf(clause.body || [])
                if (found) return found
            }
        }
    }
    return null
}

function scanBodyForZeroLenIf(body) {
    for (const stat of body) {
        if (!stat) continue
        // if #v6 == 0 then  (any unary # compared == 0)
        if (
            stat.type === "IfStatement" &&
            stat.clauses?.length >= 1
        ) {
            const cond = stat.clauses[0].condition
            const isLenCheck = (
                is(cond, { type: "BinaryExpression", operator: "==" }) &&
                (
                    is(cond.left,  { type: "UnaryExpression", operator: "#" }) ||
                    is(cond.right, { type: "UnaryExpression", operator: "#" })
                )
            )
            if (isLenCheck) {
                // payload is the body of this if, minus the trailing ReturnStatement
                const payload = (stat.clauses[0].body || []).filter(s =>
                    s && s.type && s.type !== "ReturnStatement"
                )
                if (payload.length) return payload
            }
        }
        // recurse into nested loops
        if (stat.type === "ForNumericStatement" || stat.type === "WhileStatement" ||
            stat.type === "RepeatStatement" || stat.type === "DoStatement") {
            const found = scanBodyForZeroLenIf(stat.body || [])
            if (found) return found
        }
    }
    return null
}

// ── Strategy 2: find  if r1 then <content>  where content has actual calls ──
function findPayloadInR1Block(body) {
    for (const stat of body) {
        if (!stat) continue
        if (stat.type === "IfStatement") {
            for (const clause of stat.clauses) {
                const cb = clause.body || []
                // filter out pure anti-tamper junk:
                // - AssignmentStatements that are only setting temp math vars
                // - the shuffle for-loop (ForNumericStatement with v6[k]=k)
                const real = cb.filter(s => {
                    if (!s?.type) return false
                    if (s.type === "ReturnStatement") return false
                    // keep CallStatements (print, function calls etc)
                    if (s.type === "CallStatement") return true
                    // keep LocalStatement with non-trivial init
                    if (s.type === "LocalStatement") return true
                    // keep FunctionDeclaration
                    if (s.type === "FunctionDeclaration") return true
                    // keep IfStatement (nested logic)
                    if (s.type === "IfStatement") return true
                    return false
                })
                if (real.length > 0) return real
            }
        }
    }
    return null
}

// ── Strategy 3: regex fallback — extract everything between payload markers ──
function regexFallback(src) {
    // WRD always ends payload with:  print("hai"); return; end;
    // We can't reliably regex the AST, so try to find the last meaningful
    // block before the final  return (function() while true do ... end)()

    // Find lines that are NOT part of the anti-tamper header
    const lines = src.split("\n")
    let startLine = -1
    let endLine = -1

    // The anti-tamper header ends when we see "if r1 then" or "if v2 then"
    for (let i = 0; i < lines.length; i++) {
        if (/^\s*if\s+(r1|v2)\s+then/.test(lines[i])) {
            startLine = i + 1 // line after the if
            break
        }
    }

    // payload ends before:  return (function(...) while true do
    for (let i = lines.length - 1; i >= 0; i--) {
        if (/return\s*\(function/.test(lines[i])) {
            endLine = i - 1
            break
        }
    }

    if (startLine > 0 && endLine > startLine) {
        const payload = lines.slice(startLine, endLine + 1)
            .filter(l => l.trim() !== "end;" && l.trim() !== "end")
        return payload.join("\n").trim()
    }
    return null
}

// ── run strategies ────────────────────────────────────────────────────────────
let payloadNodes = findPayloadInIfZeroLen(body)
let payloadSrc = null

if (payloadNodes && payloadNodes.length) {
    try {
        payloadSrc = beautify({ type: "Chunk", body: payloadNodes }).trim()
    } catch (_) {}
}

if (!payloadSrc || payloadSrc.length < 2) {
    payloadNodes = findPayloadInR1Block(body)
    if (payloadNodes && payloadNodes.length) {
        try {
            payloadSrc = beautify({ type: "Chunk", body: payloadNodes }).trim()
        } catch (_) {}
    }
}

if (!payloadSrc || payloadSrc.length < 2) {
    payloadSrc = regexFallback(src)
}

if (!payloadSrc || payloadSrc.length < 2) {
    console.error("ERR|Could not extract payload from WRD output")
    process.exit(1)
}

fs.writeFileSync(out, payloadSrc + "\n")
const ms = Math.floor(performance.now())
process.stdout.write(`OK|${ms}|${Buffer.byteLength(payloadSrc)}\n`)
