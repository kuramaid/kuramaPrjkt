const fs = require("fs")
const request = require("../utils/request")

const url = process.argv[2]
const out = process.argv[3]

if (!url || !out) {
    console.error("Usage: node httpget.js <url> <output>")
    process.exit(1)
}

;(async () => {
    const start = performance.now()
    const [ok, content] = await request(url)

    if (!ok) {
        console.error("ERR|" + content)
        process.exit(1)
    }

    fs.writeFileSync(out, content)
    // only print protocol line, no content
    process.stdout.write(`OK|${Math.floor(performance.now() - start)}|${Buffer.byteLength(content, "utf8")}\n`)
})()
