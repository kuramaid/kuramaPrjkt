const fs = require("fs")
const deobf = require("../parsers/lua_deobf")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node luaobf.js <input> <output>")
    process.exit(1)
}

try {
    const src = fs.readFileSync(inp, "utf8")
    const start = performance.now()
    const result = deobf(src)
    fs.writeFileSync(out, result)
    console.log(`OK|${Math.floor(performance.now() - start)}`)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}
