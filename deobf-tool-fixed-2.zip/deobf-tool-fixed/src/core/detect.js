const fs = require("fs")

const inp = process.argv[2]

if (!inp) {
    console.error("Usage: node detect.js <input>")
    process.exit(1)
}

try {
    const content = fs.readFileSync(inp, "utf8")

    let result = "Unknown"

    if (content.includes("=[LPH") || content.includes("!!LPH"))
        result = "Luraph"
    else if (content.match(/\w+\.\w+\(["']#/))
        result = "MoonSec V3"
    else if (content.match(/\d\d\d\d\d\+-?\d\d\d\d\d/))
        result = "Prometheus"
    else if (content.match(/return \w+\(\w+\(\)\s*,\s*{}\s*,\s*\w+\)\(\.\.\.\)/))
        result = "IronBrew 2"
    else if (content.match(/local\s+\w+\s*=\s*\w+\(\w+\(\w+,\s*\w+\)/))
        result = "LuaObfuscator (string enc)"
    else if (content.includes("WeAreDevs"))
        result = "WeAreDevs"

    console.log("OK|" + result)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}
