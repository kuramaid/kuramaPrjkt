const fs = require("fs")
const path = require("path")
const beautify = require("../parsers/lua_beautifier")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node beautify.js <input> <output>")
    process.exit(1)
}

try {
    const src = fs.readFileSync(inp, "utf8")
    const result = beautify(src)
    fs.writeFileSync(out, result)
    const orig = Buffer.byteLength(src, "utf8")
    const done = Buffer.byteLength(result, "utf8")
    console.log(`OK|${orig}|${done}`)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}
