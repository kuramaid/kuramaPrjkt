const fs = require("fs")

const url = process.argv[2]
const out = process.argv[3]

if (!url || !out) {
    console.error("Usage: node bypass.js <url> <output>")
    process.exit(1)
}

;(async () => {
    try {
        const start = performance.now()
        const apiUrl = `https://api.bypass.vip/premium/bypass?url=${encodeURIComponent(url)}`
        const res = await fetch(apiUrl)

        if (!res.ok) {
            console.error(`ERR|${res.status} ${res.statusText}`)
            process.exit(1)
        }

        const json = await res.json()

        if (json.status !== "success") {
            console.error("ERR|bypass failed: " + JSON.stringify(json))
            process.exit(1)
        }

        fs.writeFileSync(out, json.result)
        console.log(`OK|${Math.floor(performance.now() - start)}`)
    } catch (err) {
        console.error("ERR|" + err.message)
        process.exit(1)
    }
})()
