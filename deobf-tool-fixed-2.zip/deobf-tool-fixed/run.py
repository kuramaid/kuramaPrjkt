#!/usr/bin/env python3
import os, sys, subprocess, shutil, time
from pathlib import Path

BASE         = Path(__file__).parent.resolve()
CORE         = BASE / "src" / "core"
NODE_MODULES = BASE / "node_modules"
BIN_LUNE     = BASE / "bin" / "lune"

R="\033[91m"; G="\033[92m"; Y="\033[93m"
B="\033[94m"; C="\033[96m"; W="\033[97m"
DIM="\033[2m"; BOLD="\033[1m"; RST="\033[0m"

BLACKLISTED = ["pornhub","xvideos","xnxx","onlyfans","brazzers","youporn","redtube","tube8","spankbang"]

SETTINGS = {
    "hookOp":        {"val": True,  "desc": "Hook repeat/while/if/comparisons"},
    "explore_funcs": {"val": True,  "desc": "Log inside functions"},
    "spyexeconly":   {"val": False, "desc": "Only spy executor variables"},
    "minifier":      {"val": True,  "desc": "Inline outputs (easier to read)"},
    "constants":     {"val": False, "desc": "Collect all detected strings"},
    "lua":           {"val": False, "desc": "Allow require() with any string"},
    "roblox":        {"val": False, "desc": "Error on wrong script behavior"},
    "runtimelogs":   {"val": False, "desc": "Save scripts during processing"},
    "comments":      {"val": False, "desc": "Add comments to output code"},
    "discord":       {"val": True,  "desc": "Log as many things as possible"},
}

BESTCFG = {
    "performance": {"hookOp":-2,"runtimelogs":-1,"constants":-2},
    "output":      {"hookOp":3,"explore_funcs":1,"spyexeconly":-1,"minifier":5,"lua":3,"roblox":-1,"discord":1},
    "tamper":      {"hookOp":5,"spyexeconly":4,"constants":3,"lua":-1,"roblox":3},
}
BESTCFG_ALIASES = {"speed":"performance","antitamper":"tamper","accuracy":"output"}

def clr():    os.system("clear")
def pr(t=""): print(t)
def ok(m):    print(f"  {G}✓{RST} {m}")
def err(m):   print(f"  {R}✗{RST} {m}")
def info(m):  print(f"  {Y}→{RST} {m}")
def inp(m):   return input(f"  {C}›{RST} {m}").strip()
def sep():    print(f"  {DIM}{'─'*50}{RST}")
def wait():   input(f"\n  {Y}Tekan Enter untuk kembali...{RST}")

def title(sub=""):
    clr()
    print(f"{B}{BOLD}")
    print("  ██████╗ ███████╗ ██████╗ ██████╗ ███████╗")
    print("  ██╔══██╗██╔════╝██╔═══██╗██╔══██╗██╔════╝")
    print("  ██║  ██║█████╗  ██║   ██║██████╔╝█████╗  ")
    print("  ██║  ██║██╔══╝  ██║   ██║██╔══██╗██╔══╝  ")
    print("  ██████╔╝███████╗╚██████╔╝██████╔╝██║     ")
    print("  ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ")
    print(f"{RST}{C}          Lua Deobfuscator | KuramaMods{RST}")
    sep()
    if sub:
        print(f"\n  {BOLD}{W}[ {sub} ]{RST}\n")

def check_node():
    if not shutil.which("node"):
        err("Node.js tidak ditemukan!")
        pr(); info("Install: pkg install nodejs  atau  apt install nodejs")
        input(f"\n  {Y}Tekan Enter keluar...{RST}"); sys.exit(1)

def ensure_deps():
    title()
    info("Memeriksa dependensi...")
    pr()
    check_node()
    try:
        nv = subprocess.run(["node","--version"], capture_output=True, text=True).stdout.strip()
        ok(f"Node.js {nv}")
    except: pass

    if not NODE_MODULES.exists():
        pr(); info("Menginstall npm dependencies...")
        pr(); sep()
        subprocess.run(["npm","install","--omit=optional"], cwd=str(BASE))
        sep(); pr()
        if NODE_MODULES.exists(): ok("Dependencies terinstall!")
        else: err("Gagal install! Jalankan: npm install"); input(f"\n  {Y}Enter...{RST}"); sys.exit(1)
    else:
        ok("node_modules OK")

    pr(); ok("Siap!"); time.sleep(0.7)

def node_run(script, args=[], capture=True):
    cmd = ["node", str(CORE / script)] + [str(a) for a in args]
    r = subprocess.run(cmd, cwd=str(BASE), capture_output=capture, text=True)
    return r.returncode, r.stdout.strip() if capture else "", r.stderr.strip() if capture else ""

def fix_output(src_p, out_s, suffix, ext=".lua"):
    if not out_s:
        return Path(src_p).parent / (Path(src_p).stem + suffix + ext)
    p = Path(out_s)
    if p.is_dir() or str(out_s).endswith(("/","\\")):
        return p / (Path(src_p).stem + suffix + ext)
    return p if p.suffix else p.parent / (p.name + ext)

def validate_lua(path):
    p = Path(path)
    if not p.exists(): return False, f"File tidak ditemukan: {path}"
    if p.stat().st_size == 0: return False, "File kosong"
    return True, ""

# ─────────────────────────────────────────────────────────────────────
# [1] DEOBFUSCATE — Prometheus only
# ─────────────────────────────────────────────────────────────────────
def menu_deobf():
    title("DEOBFUSCATE  [Prometheus]")
    pr()

    src = inp("Input file (.lua): ")
    if not src: return
    ok_v, msg = validate_lua(src)
    if not ok_v: err(msg); wait(); return

    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_deobf.lua]: ")
    out_p = fix_output(src_p, out_s, "_deobf").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)

    pr(); info(f"Processing: {src_p.name}"); sep()
    t = time.time()

    # Run node, let its stdout flow directly (shows Getting constants.. etc)
    # but suppress — we only want progress, not noise. Capture and filter.
    proc = subprocess.run(
        ["node", str(CORE / "main.js"), str(src_p), str(out_p)],
        cwd=str(BASE),
        capture_output=True,
        text=True
    )
    elapsed = time.time() - t

    # Print only meaningful progress lines, skip internal debug/key dumps
    SKIP_PREFIXES = (
        "Encryption Keys:", "FOUND DECRYPTION KEY",
        "decryptor is inlined", "sorry bud",
        "Encrypt strings is off",
    )
    for line in (proc.stdout + proc.stderr).splitlines():
        line = line.strip()
        if not line: continue
        skip = any(line.startswith(p) for p in SKIP_PREFIXES)
        if not skip:
            print(f"  {DIM}{line}{RST}")

    sep(); pr()
    if proc.returncode == 0:
        size = out_p.stat().st_size if out_p.exists() else 0
        ok(f"Selesai dalam {elapsed:.2f}s")
        ok(f"Output: {out_p}  ({size:,} bytes)")
    else:
        err(f"Gagal (exit code {proc.returncode})")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [2] BEAUTIFY
# ─────────────────────────────────────────────────────────────────────
def menu_beautify():
    title("BEAUTIFY LUA  [bf / coolify]")
    info("Format/beautify kode Lua")
    pr()
    src = inp("Input file (.lua/.luau): ")
    if not src: return
    ok_v, msg = validate_lua(src)
    if not ok_v: err(msg); wait(); return
    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_formatted.lua]: ")
    out_p = fix_output(src_p, out_s, "_formatted").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)
    pr(); info("Beautifying..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("beautify.js", [src_p, out_p])
    elapsed = time.time() - t
    sep(); pr()
    if code == 0 and stdout.startswith("OK|"):
        parts = stdout.split("|")
        ok(f"Selesai dalam {elapsed:.2f}s")
        ok(f"Ukuran: {parts[1]} → {parts[2]} bytes")
        ok(f"Output: {out_p}")
    else:
        err("Gagal beautify")
        if stderr: print(f"  {DIM}{stderr}{RST}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [3] MINIFY
# ─────────────────────────────────────────────────────────────────────
def menu_minify():
    title("MINIFY LUA")
    info("Minify/compress kode Lua")
    pr()
    src = inp("Input file (.lua): ")
    if not src: return
    ok_v, msg = validate_lua(src)
    if not ok_v: err(msg); wait(); return
    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_min.lua]: ")
    out_p = fix_output(src_p, out_s, "_min").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)
    pr(); info("Minifying..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("minify.js", [src_p, out_p])
    elapsed = time.time() - t
    sep(); pr()
    if code == 0 and stdout.startswith("OK|"):
        parts = stdout.split("|")
        orig, done = int(parts[1]), int(parts[2])
        pct = (1 - done/orig)*100 if orig else 0
        ok(f"Selesai dalam {elapsed:.2f}s")
        ok(f"Ukuran: {orig} → {done} bytes ({pct:.1f}% lebih kecil)")
        ok(f"Output: {out_p}")
    else:
        err("Gagal minify")
        if stderr: print(f"  {DIM}{stderr}{RST}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [4] LUAOBF DEOBF
# ─────────────────────────────────────────────────────────────────────
def menu_luaobf():
    title("LUAOBFUSCATOR DEOBF  [noluaobf]")
    info("Deobfuscate file luaobfuscator.com (string encryption)")
    pr()
    src = inp("Input file (.lua): ")
    if not src: return
    ok_v, msg = validate_lua(src)
    if not ok_v: err(msg); wait(); return
    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_deobf.lua]: ")
    out_p = fix_output(src_p, out_s, "_deobf").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)
    pr(); info("Deobfuscating luaobf..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("luaobf.js", [src_p, out_p])
    elapsed = time.time() - t
    sep(); pr()
    if code == 0 and stdout.startswith("OK|"):
        ms = stdout.split("|")[1]
        ok(f"Selesai dalam {ms}ms")
        ok(f"Output: {out_p}")
    else:
        err("Gagal deobfuscate")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
        pr(); info("Pastikan file dari luaobfuscator.com dengan string encryption only.")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [5] WEAREDEVS OBFUSCATE — API only
# ─────────────────────────────────────────────────────────────────────
def menu_wrd():
    title("WEAREDEVS OBFUSCATE  [wearedevs]")
    info("Kirim ke WeAreDevs API (online)")
    pr()
    src = inp("Input file (.lua): ")
    if not src: return
    ok_v, msg = validate_lua(src)
    if not ok_v: err(msg); wait(); return
    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_obf.lua]: ")
    out_p = fix_output(src_p, out_s, "_obf").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)

    pr(); info("Mengirim ke WeAreDevs API..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("wearedevs.js", [src_p, out_p, "api"])
    elapsed = time.time() - t
    sep(); pr()
    if code == 0 and stdout.startswith("OK|"):
        ms = stdout.split("|")[1]
        ok(f"Selesai dalam {ms}ms")
        ok(f"Output: {out_p}")
    else:
        err("Gagal obfuscate")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [6] WRD STRIP — extract original payload from WRD obfuscated output
# ─────────────────────────────────────────────────────────────────────
def menu_wrdstrip():
    title("WRD STRIP  [wrdstrip]")
    info("Hapus anti-tamper WeAreDevs, ambil payload asli")
    pr()
    src = inp("Input file (.lua hasil WRD): ")
    if not src: return
    ok_v, msg = validate_lua(src)
    if not ok_v: err(msg); wait(); return
    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_stripped.lua]: ")
    out_p = fix_output(src_p, out_s, "_stripped").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)
    pr(); info("Stripping WRD wrapper..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("wrdstrip.js", [src_p, out_p])
    elapsed = time.time() - t
    sep(); pr()
    if code == 0 and stdout.startswith("OK|"):
        parts = stdout.split("|")
        ok(f"Selesai dalam {elapsed:.2f}s")
        ok(f"Output: {out_p}  ({parts[2]} bytes)")
    else:
        err("Gagal strip WRD wrapper")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
        pr(); info("Pastikan file adalah hasil obfuscate WeAreDevs (API).")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [7] HTTP GET — silent  
# ─────────────────────────────────────────────────────────────────────
def menu_httpget():
    title("HTTP GET  [http / httpget / wget]")
    info("GET request ke URL — pakai Roblox-spoofed headers")
    pr()
    url = inp("URL (https://...): ")
    if not url: return
    if not url.startswith("http"):
        err("URL harus dimulai dengan http/https"); wait(); return
    for site in BLACKLISTED:
        if site in url.lower():
            err("URL diblacklist"); wait(); return
    out_s = inp("Output file [result.txt]: ") or "result.txt"
    out_p = Path(out_s).resolve()
    if out_p.is_dir(): out_p = out_p / "result.txt"
    out_p.parent.mkdir(parents=True, exist_ok=True)
    pr(); info(f"Fetching: {url}"); sep()
    t = time.time()
    code, stdout, stderr = node_run("httpget.js", [url, out_p])
    elapsed = time.time() - t
    sep(); pr()
    if code == 0 and stdout.startswith("OK|"):
        parts = stdout.split("|")
        ok(f"Selesai dalam {parts[1]}ms")
        ok(f"Ukuran: {parts[2]} bytes")
        ok(f"Output: {out_p}")
    else:
        err("Gagal fetch URL")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [7] BYPASS LINK
# ─────────────────────────────────────────────────────────────────────
def menu_bypass():
    title("BYPASS LINK  [bp]")
    info("Bypass advertisement/shortlink via bypass.vip")
    pr()
    url = inp("Link (https://...): ")
    if not url: return
    if not url.startswith("http"):
        err("Link harus dimulai dengan http/https"); wait(); return
    out_s = inp("Output file [bypassed.txt]: ") or "bypassed.txt"
    out_p = Path(out_s).resolve()
    if out_p.is_dir(): out_p = out_p / "bypassed.txt"
    out_p.parent.mkdir(parents=True, exist_ok=True)
    pr(); info(f"Bypassing: {url}"); sep()
    t = time.time()
    code, stdout, stderr = node_run("bypass.js", [url, out_p])
    elapsed = time.time() - t
    sep(); pr()
    if code == 0 and stdout.startswith("OK|"):
        ms = stdout.split("|")[1]
        ok(f"Berhasil dalam {ms}ms!")
        ok(f"Output: {out_p}")
    else:
        err("Gagal bypass")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [8] SETTINGS
# ─────────────────────────────────────────────────────────────────────
def menu_cfg():
    while True:
        title("SETTINGS  [cfg / settings]")
        keys = list(SETTINGS.keys())
        for i, k in enumerate(keys):
            s = SETTINGS[k]
            state = f"{G}ON {RST}" if s["val"] else f"{R}OFF{RST}"
            print(f"  {DIM}[{i+1:2}]{RST} {state}  {k:<16} {DIM}{s['desc']}{RST}")
        pr()
        print(f"  {DIM}[ b]{RST} Kembali")
        print(f"  {DIM}[ r]{RST} Reset default")
        pr()
        c = inp("Toggle nomor / b / r: ")
        if c.lower() in ("b",""): return
        if c.lower() == "r":
            defaults = {"hookOp":True,"explore_funcs":True,"spyexeconly":False,
                        "minifier":True,"constants":False,"lua":False,
                        "roblox":False,"runtimelogs":False,"comments":False,"discord":True}
            for k,v in defaults.items():
                if k in SETTINGS: SETTINGS[k]["val"] = v
            ok("Reset ke default"); time.sleep(0.5); continue
        try:
            idx = int(c)-1
            if 0 <= idx < len(keys):
                k = keys[idx]
                SETTINGS[k]["val"] = not SETTINGS[k]["val"]
                ok(f"{k} → {'ON' if SETTINGS[k]['val'] else 'OFF'}")
                time.sleep(0.3)
        except ValueError:
            err("Input tidak valid"); time.sleep(0.4)

# ─────────────────────────────────────────────────────────────────────
# [9] BEST CONFIG
# ─────────────────────────────────────────────────────────────────────
def menu_bestcfg():
    title("BEST CONFIG")
    info("Auto-apply pengaturan terbaik berdasarkan mode")
    pr()
    for alias, key in BESTCFG_ALIASES.items():
        print(f"  {G}·{RST} {alias:<15} {DIM}(= {key}){RST}")
    for key in BESTCFG:
        if key not in BESTCFG_ALIASES.values():
            print(f"  {G}·{RST} {key}")
    pr()
    modes_in = inp("Mode (pisah koma, cth: speed,accuracy): ")
    if not modes_in: return
    modes = [m.strip().lower() for m in modes_in.split(",") if m.strip()]
    cfg = {}
    for m in modes:
        key = BESTCFG_ALIASES.get(m, m)
        diff = BESTCFG.get(key)
        if not diff: err(f"Mode tidak valid: {m}"); wait(); return
        for s, change in diff.items():
            cfg[s] = cfg.get(s, 0) + change
    changed = []
    for k, score in cfg.items():
        if k not in SETTINGS: continue
        nv = score > 0
        if SETTINGS[k]["val"] != nv:
            SETTINGS[k]["val"] = nv
            changed.append(f"{'+ ' if nv else '- '}{k}")
    pr()
    if not changed: info("Tidak ada setting yang berubah")
    else:
        ok("Settings diupdate:")
        for r in changed: print(f"    {r}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [a] DETECT OBFUSCATOR
# ─────────────────────────────────────────────────────────────────────
def menu_detect():
    title("DETECT OBFUSCATOR")
    pr()
    src = inp("Input file (.lua): ")
    if not src: return
    ok_v, msg = validate_lua(src)
    if not ok_v: err(msg); wait(); return
    src_p = Path(src).resolve()
    pr(); info("Mendeteksi..."); sep()
    code, stdout, stderr = node_run("detect.js", [src_p])
    sep(); pr()
    if code == 0 and stdout.startswith("OK|"):
        ok(f"Terdeteksi: {BOLD}{stdout.split('|',1)[1]}{RST}")
    else:
        err("Gagal deteksi")
        if stderr: print(f"  {DIM}{stderr}{RST}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [b] BATCH DEOBFUSCATE
# ─────────────────────────────────────────────────────────────────────
def menu_batch():
    title("BATCH DEOBFUSCATE  [Prometheus]")
    pr()
    folder = inp("Folder input: ")
    if not folder: return
    folder_p = Path(folder).resolve()
    if not folder_p.is_dir():
        err(f"Folder tidak ditemukan: {folder}"); wait(); return
    files = list(folder_p.glob("*.lua")) + list(folder_p.glob("*.luau"))
    if not files:
        err("Tidak ada file .lua/.luau"); wait(); return
    pr(); info(f"Ditemukan {len(files)} file:")
    for f in files: print(f"  {DIM}· {f.name}{RST}")
    pr()
    out_s = inp(f"Folder output [{folder_p}/output]: ")
    out_folder = Path(out_s).resolve() if out_s else folder_p / "output"
    out_folder.mkdir(parents=True, exist_ok=True)
    pr(); sep()
    ok_n = fail_n = 0
    for f in files:
        out_f = out_folder / (f.stem + "_deobf.lua")
        info(f"Processing: {f.name}")
        code = subprocess.run(
            ["node", str(CORE / "main.js"), str(f), str(out_f)],
            cwd=str(BASE), capture_output=True
        ).returncode
        if code == 0: ok(f"  → {out_f.name}"); ok_n += 1
        else:         err(f"  → Gagal"); fail_n += 1
        pr()
    sep(); pr()
    ok(f"Berhasil: {ok_n}/{len(files)}")
    if fail_n: err(f"Gagal: {fail_n}/{len(files)}")
    ok(f"Output: {out_folder}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# [i] INFO
# ─────────────────────────────────────────────────────────────────────
def menu_info():
    title("INFO SISTEM")
    try: nv = subprocess.run(["node","--version"], capture_output=True, text=True).stdout.strip()
    except: nv = "N/A"
    try: npmv = subprocess.run(["npm","--version"], capture_output=True, text=True).stdout.strip()
    except: npmv = "N/A"
    js_files  = list((BASE / "src").rglob("*.js"))
    lua_files = list((BASE / "lua").rglob("*.lua"))
    print(f"  {C}Node.js  :{RST} {nv}")
    print(f"  {C}npm      :{RST} {npmv}")
    print(f"  {C}Deps     :{RST} {'✓' if NODE_MODULES.exists() else '✗ Belum install'}")
    print(f"  {C}JS files :{RST} {len(js_files)}")
    print(f"  {C}Lua refs :{RST} {len(lua_files)}")
    print(f"  {C}Base dir :{RST} {BASE}")
    pr()
    print(f"  {BOLD}Fitur:{RST}")
    cmds = [
        ("deobf",       "Prometheus deobfuscate (cleaner output)"),
        ("bf/coolify",  "Beautify Lua"),
        ("minify",      "Minify Lua"),
        ("noluaobf",    "LuaObfuscator deobf"),
        ("wearedevs",   "WeAreDevs obfuscate (API)"),
        ("http/wget",   "HTTP GET — Roblox-spoofed headers"),
        ("bp",          "Bypass shortlink"),
        ("cfg",         "Settings"),
        ("bestcfg",     "Auto best settings"),
        ("detect",      "Deteksi obfuscator"),
        ("batch",       "Batch deobfuscate"),
    ]
    for alias, desc in cmds:
        print(f"  {DIM}·{RST} {G}{alias:<20}{RST} {DIM}{desc}{RST}")
    wait()

# ─────────────────────────────────────────────────────────────────────
# MAIN MENU
# ─────────────────────────────────────────────────────────────────────
def main():
    ensure_deps()
    menu_map = {
        "1": menu_deobf,
        "2": menu_beautify,
        "3": menu_minify,
        "4": menu_luaobf,
        "5": menu_wrd,
        "6": menu_wrdstrip,
        "7": menu_httpget,
        "8": menu_bypass,
        "9": menu_cfg,
        "a": menu_detect,
        "b": menu_batch,
        "c": menu_bestcfg,
        "i": menu_info,
    }
    while True:
        title()
        print(f"  {BOLD}MENU UTAMA{RST}\n")
        print(f"  {G}[1]{RST} Deobfuscate          {DIM}Prometheus{RST}")
        print(f"  {G}[2]{RST} Beautify Lua          {DIM}bf / coolify{RST}")
        print(f"  {G}[3]{RST} Minify Lua")
        print(f"  {G}[4]{RST} LuaObfuscator Deobf   {DIM}noluaobf{RST}")
        print(f"  {G}[5]{RST} WeAreDevs Obfuscate   {DIM}API{RST}")
        print(f"  {G}[6]{RST} WRD Strip             {DIM}hapus anti-tamper, ambil payload{RST}")
        print(f"  {G}[7]{RST} HTTP GET              {DIM}http / httpget / wget{RST}")
        print(f"  {G}[8]{RST} Bypass Link           {DIM}bp{RST}")
        print(f"  {G}[9]{RST} Settings              {DIM}cfg{RST}")
        print(f"  {G}[a]{RST} Deteksi Obfuscator")
        print(f"  {G}[b]{RST} Batch Deobfuscate")
        print(f"  {G}[c]{RST} Best Config           {DIM}bestcfg{RST}")
        print(f"  {G}[i]{RST} Info Sistem")
        print(f"  {R}[0]{RST} Keluar")
        pr()
        c = inp("Pilih: ").lower()
        if c == "0":
            title(); print(f"  {C}Bye!{RST}\n"); sys.exit(0)
        elif c in menu_map:
            menu_map[c]()
        else:
            err("Pilihan tidak valid"); time.sleep(0.4)

if __name__ == "__main__":
    main()
