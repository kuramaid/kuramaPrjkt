const fs = require("fs")

const inp = process.argv[2]

if (!inp) {
    console.error("Usage: node index.js <input>")
    process.exit(1)
}

try {
    const src = fs.readFileSync(inp, "utf8")
    let result = "Unknown"

    if (src.includes("=[LPH") || src.includes("!!LPH"))
        result = "Luraph"
    else if (src.match(/\w+\.\w+\(["']#/) || src.match(/\w+\s*\(\s*\d+\s*,\s*"[A-Za-z0-9+/=]{20,}"\s*\)/) && src.match(/This file was protected with MoonSec/))
        result = "MoonSec V3"
    else if (src.includes("This file was protected with MoonSec V3"))
        result = "MoonSec V3"
    else if (src.match(/\d\d\d\d\d\+-?\d\d\d\d\d/))
        result = "Prometheus"
    else if (src.match(/return \w+\(\w+\(\)\s*,\s*{}\s*,\s*\w+\)\(\.\.\.\)/))
        result = "IronBrew 2"
    else if (src.match(/local\s+\w+\s*=\s*\w+\(\w+\(\w+,\s*\w+\)/))
        result = "LuaObfuscator (string enc)"
    else if (src.includes("WeAreDevs"))
        result = "WeAreDevs"

    console.log("OK|" + result)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}
