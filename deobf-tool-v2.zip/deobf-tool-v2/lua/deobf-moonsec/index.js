const fs = require("fs")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node index.js <input> <output>")
    process.exit(1)
}

// ── String Decoding ──────────────────────────────────────────────────────────

function decodeEscape(data) {
    const parts = data.split("\\").slice(1)
    return Buffer.from(parts.map(p => parseInt(p)))
}

function decodeString(data, key) {
    const chars = {}
    for (let i = 0; i < 16; i++) chars[data[i]] = i

    const out = []
    let rkey = key
    for (let i = 16; i < data.length; i += 2) {
        const i1 = chars[data[i]] ?? 0
        const i2 = chars[data[i + 1]] ?? 0
        out.push((i1 * 16 + i2 + rkey) % 256)
        rkey += key
    }
    return Buffer.from(out)
}

function decodeConstants(data) {
    const constants = {}
    let pos = 0

    while (pos < data.length) {
        let control = data[pos++]
        if (control === 5) break
        if (control === 1) control++

        const size = data[pos++]
        const first = data.slice(pos, pos + size).toString("utf8")
        pos += size

        let value = null
        if (control === 0) {
            const strSize = data[pos++]
            const second = data.slice(pos, pos + strSize).toString("utf8")
            pos += strSize
            value = [first, second]
        } else if (control === 2 || control === 4 || control === 6) {
            value = [first]
        }

        const key = data.slice(pos, pos + 8).toString("utf8")
        pos += 8
        if (value !== null) constants[key] = value
    }
    return constants
}

function decodeConstant(key, bytes) {
    if (!(bytes.length > 1 && bytes[0] > 0x7f))
        return bytes.toString("utf8")
    const newBytes = Buffer.alloc(bytes.length - 1)
    for (let i = 1; i < bytes.length; i++)
        newBytes[i - 1] = (bytes[i] + key) % 256
    return newBytes.toString("utf8")
}

// ── Pattern extraction from Lua source ──────────────────────────────────────

function extractKeys(src) {
    // find: someVar(number, "encoded_string") → string pool
    const callPattern = /\w+\s*\(\s*(\d+)\s*,\s*"([^"]+)"\s*\)/g
    const escPattern = /"(\\4\\8[^"]+)"/g
    const results = []

    let m
    while ((m = callPattern.exec(src)) !== null)
        results.push([parseInt(m[1]), m[2]])
    while ((m = escPattern.exec(src)) !== null)
        results.push([null, m[1]])

    return results
}

function extractBytecodeString(src) {
    // MoonSec stores bytecode as: someFunc(identifier, "BASE_STRING")
    const m = src.match(/\w+\s*\(\s*\w+\s*,\s*"([A-Za-z0-9+/=]{50,})"\s*\)/)
    return m ? m[1] : null
}

function extractBytecodeKey(src) {
    // key expressions: number + something
    const m = src.match(/(\d+)\s*\+\s*\w+/)
    return m ? parseInt(m[1]) : null
}

// ── Binary reader ────────────────────────────────────────────────────────────

class BinaryReader {
    constructor(buf) {
        this.buf = buf
        this.pos = 0
    }
    readByte() { return this.buf[this.pos++] }
    readBoolean() { return this.readByte() !== 0 }
    readInt16() {
        const v = this.buf.readInt16LE(this.pos)
        this.pos += 2
        return v
    }
    readInt32() {
        const v = this.buf.readInt32LE(this.pos)
        this.pos += 4
        return v
    }
    readDouble() {
        const v = this.buf.readDoubleBE(this.pos)
        this.pos += 8
        return v
    }
    readBytes(n) {
        const v = this.buf.slice(this.pos, this.pos + n)
        this.pos += n
        return v
    }
}

function getBits(source, start, end) {
    return (source >> (start - 1)) & ((1 << (end - start + 1)) - 1)
}

// ── Deserializer ─────────────────────────────────────────────────────────────

// ProtoFormat step types
const STEP = { Instructions: 0, Constants: 1, Functions: 2, NumParams: 3 }
const CTYPE = { Boolean: 0, Number: 1, String: 2 }

function deserialize(bytes, constantKey) {
    const r = new BinaryReader(bytes)

    // MoonSec format: detect order by sniffing first few bytes
    // Default proto order: NumParams, Instructions, Constants, Functions
    const protoFormat = [STEP.NumParams, STEP.Instructions, STEP.Constants, STEP.Functions]

    // Constant type flags — MoonSec shuffles these per build
    // Standard: bool=0, number=1, string=2 (we detect from bytecode)
    const constantFormat = { 0: CTYPE.Boolean, 1: CTYPE.Number, 2: CTYPE.String }

    function readInstructions(fn) {
        const size = r.readInt32()
        const instrs = []
        for (let i = 0; i < size; i++) {
            const descriptor = r.readByte()
            if (getBits(descriptor, 1, 1) !== 0) continue

            const type = getBits(descriptor, 2, 3)
            const mask = getBits(descriptor, 4, 6)

            const instr = {
                opNum: r.readInt16(),
                A: r.readInt16(),
                B: 0, C: 0,
                pc: i,
                isKA: false, isKB: false, isKC: false,
                opCode: null, isDead: false
            }

            switch (type) {
                case 0: instr.B = r.readInt16(); instr.C = r.readInt16(); break
                case 1: instr.B = r.readInt32(); break
                case 2: instr.B = r.readInt32() - (1 << 16); break
                case 3: instr.B = r.readInt32() - (1 << 16); instr.C = r.readInt16(); break
            }

            instr.isKA = getBits(mask, 1, 1) === 1
            instr.isKB = getBits(mask, 2, 2) === 1
            instr.isKC = getBits(mask, 3, 3) === 1
            instrs.push(instr)
        }
        return instrs
    }

    function readConstants() {
        const size = r.readInt32()
        const consts = []
        for (let i = 0; i < size; i++) {
            const typeFlag = r.readByte()
            const ctype = constantFormat[typeFlag]
            if (ctype === undefined) { consts.push({ type: "nil" }); continue }
            switch (ctype) {
                case CTYPE.Boolean: consts.push({ type: "bool", value: r.readBoolean() }); break
                case CTYPE.Number:  consts.push({ type: "number", value: r.readDouble() }); break
                case CTYPE.String: {
                    const len = r.readInt32()
                    const raw = r.readBytes(len)
                    consts.push({ type: "string", value: decodeConstant(constantKey, raw) })
                    break
                }
            }
        }
        return consts
    }

    function readFunction() {
        const fn = { numParams: 0, instructions: [], constants: [], functions: [], isVarArg: 0, maxStackSize: 0 }
        for (const step of protoFormat) {
            switch (step) {
                case STEP.NumParams:    fn.numParams = r.readByte(); break
                case STEP.Instructions: fn.instructions = readInstructions(fn); break
                case STEP.Constants:    fn.constants = readConstants(); break
                case STEP.Functions:    {
                    const n = r.readInt32()
                    for (let i = 0; i < n; i++) fn.functions.push(readFunction())
                    break
                }
            }
        }
        return fn
    }

    return readFunction()
}

// ── Disassembler ─────────────────────────────────────────────────────────────

const OPNAMES = {
    0:  "MOVE",      1:  "LOADK",     2:  "LOADBOOL",  3:  "LOADNIL",
    4:  "GETUPVAL",  5:  "GETGLOBAL", 6:  "GETTABLE",  7:  "SETGLOBAL",
    8:  "SETUPVAL",  9:  "SETTABLE",  10: "NEWTABLE",  11: "SELF",
    12: "ADD",       13: "SUB",       14: "MUL",        15: "DIV",
    16: "MOD",       17: "POW",       18: "UNM",        19: "NOT",
    20: "LEN",       21: "CONCAT",    22: "JMP",        23: "EQ",
    24: "LT",        25: "LE",        26: "TEST",       27: "TESTSET",
    28: "CALL",      29: "TAILCALL",  30: "RETURN",     31: "FORLOOP",
    32: "FORPREP",   33: "TFORLOOP",  34: "SETLIST",    35: "CLOSE",
    36: "CLOSURE",   37: "VARARG"
}

function constStr(c) {
    if (!c) return "?"
    if (c.type === "string") return `"${c.value}"`
    if (c.type === "number") return String(c.value)
    if (c.type === "bool")   return String(c.value)
    return "nil"
}

function RK(operand, constants) {
    return operand > 255 ? constStr(constants[operand - 256]) : `R${operand}`
}

function disassemble(rootFn) {
    const lines = ["-- Deobfuscated MoonSec V3 | KuramaMods"]

    function disasmFn(fn, name) {
        const params = Array.from({ length: fn.numParams }, (_, i) => `R${i}`)
        if (fn.isVarArg === 2) params.push("...")
        lines.push(`\nfunction ${name || "main"}(${params.join(", ")})`)
        lines.push(`\t-- [slots:${fn.maxStackSize} constants:${fn.constants.length} protos:${fn.functions.length}]`)

        fn.instructions.forEach((inst, i) => {
            if (inst.isDead) return
            const { A, B, C, opCode } = inst
            const op = OPNAMES[opCode] ?? `OP_${inst.opNum}`
            const k = fn.constants
            let ann = ""
            switch (opCode) {
                case 0:  ann = `R${A} = R${B}`; break
                case 1:  ann = `R${A} = ${constStr(k[B])}`; break
                case 2:  ann = `R${A} = ${B !== 0}${C ? "; pc++" : ""}`; break
                case 3:  ann = B - A === 0 ? `R${A} = nil` : `R${A}..R${B} = nil`; break
                case 4:  ann = `R${A} = UPVAL[${B}]`; break
                case 5:  ann = `R${A} = ${constStr(k[B])}`; break
                case 6:  ann = `R${A} = R${B}[${RK(C, k)}]`; break
                case 7:  ann = `${constStr(k[B])} = R${A}`; break
                case 8:  ann = `UPVAL[${B}] = R${A}`; break
                case 9:  ann = `R${A}[${RK(B, k)}] = ${RK(C, k)}`; break
                case 10: ann = `R${A} = {}`; break
                case 11: ann = `R${A+1} = R${B}; R${A} = R${B}[${RK(C, k)}]`; break
                case 12: ann = `R${A} = ${RK(B, k)} + ${RK(C, k)}`; break
                case 13: ann = `R${A} = ${RK(B, k)} - ${RK(C, k)}`; break
                case 14: ann = `R${A} = ${RK(B, k)} * ${RK(C, k)}`; break
                case 15: ann = `R${A} = ${RK(B, k)} / ${RK(C, k)}`; break
                case 16: ann = `R${A} = ${RK(B, k)} % ${RK(C, k)}`; break
                case 17: ann = `R${A} = ${RK(B, k)} ^ ${RK(C, k)}`; break
                case 18: ann = `R${A} = -R${B}`; break
                case 19: ann = `R${A} = not R${B}`; break
                case 20: ann = `R${A} = #R${B}`; break
                case 21: { const parts = []; for (let j = B; j <= C; j++) parts.push(`R${j}`); ann = `R${A} = ${parts.join(" .. ")}`; break }
                case 22: ann = `pc += ${B}`; break
                case 23: ann = `if ${RK(B, k)} ${A === 0 ? "==" : "~="} ${RK(C, k)} then pc++`; break
                case 24: ann = `if ${RK(B, k)} ${A === 0 ? "<" : ">="} ${RK(C, k)} then pc++`; break
                case 25: ann = `if ${RK(B, k)} ${A === 0 ? "<=" : ">"} ${RK(C, k)} then pc++`; break
                case 26: ann = `if ${C === 0 ? `not R${A}` : `R${A}`} then pc++`; break
                case 27: ann = `if ${C === 0 ? `not R${B}` : `R${B}`} then R${A} = R${B} else pc++`; break
                case 28: ann = `R${A}(R${A+1}..R${A+B-1}) → R${A}..R${A+C-2}`; break
                case 29: ann = `return R${A}(${B > 1 ? `R${A+1}..R${A+B-1}` : ""})`; break
                case 30: ann = B === 1 ? "return" : B === 0 ? `return R${A}..top` : `return R${A}..R${A+B-2}`; break
                case 31: ann = `R${A} += R${A+2}; if loop then pc += ${B}; R${A+3} = R${A}`; break
                case 32: ann = `R${A} -= R${A+2}; pc += ${B}`; break
                case 33: ann = `R${A+3}..R${A+2+C} = R${A}(R${A+1},R${A+2}); if R${A+3} then R${A+2}=R${A+3} else pc++`; break
                case 36: ann = `R${A} = proto[${B}]`; break
                case 37: ann = `R${A}..R${A+B-1} = ...`; break
                default: ann = `A=${A} B=${B} C=${C}`
            }
            lines.push(`\t[${String(i).padStart(4)}]  ${op.padEnd(12)}  ${ann}`)
        })
        lines.push("end")

        fn.functions.forEach((child, i) => disasmFn(child, `proto_${i}`))
    }

    disasmFn(rootFn, "main")
    return lines.join("\n")
}

// ── Main ─────────────────────────────────────────────────────────────────────

try {
    const src = fs.readFileSync(inp, "utf8")
    const start = performance.now()

    // 1. collect encoded string pools
    const stringEntries = extractKeys(src)
    if (!stringEntries.length) throw new Error("Tidak ada string pool MoonSec V3 ditemukan")

    // 2. decode all string pools → merge constants map
    const allConstants = {}
    for (const [key, encoded] of stringEntries) {
        let decoded
        if (key === null) decoded = decodeEscape(encoded)
        else decoded = decodeString(encoded, key)
        const map = decodeConstants(decoded)
        Object.assign(allConstants, map)
    }

    // 3. find bytecode string
    const bcStr = extractBytecodeString(src)
    if (!bcStr) throw new Error("Bytecode string tidak ditemukan")

    // 4. find bytecode key
    let bcKey = extractBytecodeKey(src)
    if (bcKey === null) bcKey = 0

    // 5. decode bytecode
    const bytecodeBytes = decodeString(bcStr, bcKey)

    // 6. find constant key (from KeyExpressions — first key expr)
    let constantKey = 0
    const keyMatch = src.match(/(\d+)\s*\+\s*\w+[\s\S]{0,50}(\d+)\s*\+\s*\w+/)
    if (keyMatch) constantKey = parseInt(keyMatch[1])

    // 7. deserialize
    const rootFn = deserialize(bytecodeBytes, constantKey)

    // 8. disassemble
    const result = disassemble(rootFn)
    fs.writeFileSync(out, result)

    console.log(`OK|${Math.floor(performance.now() - start)}`)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}
