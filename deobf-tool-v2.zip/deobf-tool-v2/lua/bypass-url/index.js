const fs = require("fs")

const url = process.argv[2]
const out = process.argv[3]

if (!url || !out) {
    console.error("Usage: node index.js <url> <output>")
    process.exit(1)
}

async function bypvip(url) {
    const res = await fetch(
        `https://api.bypass.vip/premium/bypass?url=${encodeURIComponent(url)}`,
        { headers: { "x-api-key": "e403837d-c640-4017-bb36-581759c79ecf" } }
    )
    if (!res.ok) throw new Error(`bypass.vip HTTP ${res.status}`)
    const json = await res.json()
    if (json.status !== "success" || !json.result) throw new Error(json.message || "bypass.vip fail")
    return json.result
}

async function byplat(url) {
    const res = await fetch(
        `https://iwoozie.baby/api/free/bypass?url=${encodeURIComponent(url)}`
    )
    if (!res.ok) throw new Error(`iwoozie HTTP ${res.status}`)
    const json = await res.json()
    const bad = ["Invalid URL given", "Unsupported URL given", "Not Supported by FREE API!", "bypass fail"]
    if (!json.result || bad.some(b => json.result.includes(b))) throw new Error(json.result || "iwoozie fail")
    return json.result
}

;(async () => {
    try {
        const start = performance.now()
        const timeout = new Promise((_, rej) =>
            setTimeout(() => rej(new Error("Timeout 90s")), 90000)
        )

        const race = Promise.any([bypvip(url), byplat(url)])
        const result = await Promise.race([race, timeout])

        fs.writeFileSync(out, result)
        console.log(`OK|${Math.floor(performance.now() - start)}`)
    } catch (err) {
        console.error("ERR|" + err.message)
        process.exit(1)
    }
})()
