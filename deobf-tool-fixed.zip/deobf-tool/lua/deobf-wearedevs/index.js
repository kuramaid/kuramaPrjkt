// deobf-wearedevs/index.js
// Strip WRD anti-tamper wrapper dari output WeAreDevs obfuscator
// Berdasarkan analisis prometheus source code (AntiTamper.lua, Watermark.lua, WatermarkCheck.lua)
//
// Struktur WRD output:
//   [0] watermark:gsub(...) (Watermark step)
//   [1] if _VAR ~= "..." then return end (WatermarkCheck step)
//   [2] do local valid = '...'; ... repeat until valid; end (AntiTamper step)
//   [3+] prometheus VM: return (function(...) ... end)(...) ← PAYLOAD yang kita inginkan
//
// Solusi: buang statement 0,1,2 dan ambil sisanya (statement 3+)

const fs = require("fs")
const path = require("path")
const { parse, defaultOptions } = require("../../src/parsers/luaparse")
const beautify = require("../../src/parsers/beautifier")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node index.js <input> <output>")
    process.exit(1)
}

// ── Helper: shallow node match ─────────────────────────────────────────────────
function is(node, tmpl) {
    if (!node || !tmpl) return false
    for (const k in tmpl) {
        if (tmpl[k] === null) { if (node[k] != null) return false; continue }
        if (typeof tmpl[k] === "object") {
            if (!is(node[k], tmpl[k])) return false
        } else if (node[k] !== tmpl[k]) return false
    }
    return true
}

// ── Deteksi apakah statement adalah watermark (string:gsub) ───────────────────
function isWatermarkStatement(stat) {
    // "string":gsub(".+", function(x) _VAR = x end)
    if (stat.type !== "CallStatement") return false
    const expr = stat.expression
    if (!expr) return false
    // CallExpression dimana base adalah MemberExpression dengan gsub
    const base = expr.base
    if (!base) return false
    if (base.type === "MemberExpression" && base.identifier?.name === "gsub") return true
    // Juga handle IndexExpression["gsub"]
    if (base.type === "IndexExpression") return true
    return false
}

// ── Deteksi apakah statement adalah AssignmentStatement ke watermark var ──────
function isWatermarkAssignment(stat) {
    // _VAR = "string" pattern
    if (stat.type !== "AssignmentStatement") return false
    const vars = stat.variables || []
    const inits = stat.init || []
    if (vars.length === 1 && inits.length === 1) {
        const v = vars[0]
        const val = inits[0]
        return v.type === "Identifier" && val.type === "StringLiteral"
    }
    return false
}

// ── Deteksi apakah statement adalah watermark check (if _VAR ~= "..." then return end) ──
function isWatermarkCheckStatement(stat) {
    if (stat.type !== "IfStatement") return false
    const cond = stat.clauses?.[0]?.condition
    if (!cond) return false
    return is(cond, { type: "BinaryExpression", operator: "~=" }) ||
           is(cond, { type: "BinaryExpression", operator: "==" })
}

// ── Deteksi apakah statement adalah anti-tamper do...end block ────────────────
// Cirinya: DoStatement dengan body yang mengandung 'valid' variable dan 'repeat until valid'
function isAntiTamperDoBlock(stat) {
    if (stat.type !== "DoStatement") return false
    const body = stat.body || []
    // Cek ada local valid = '...' atau local valid = true
    const hasValidLocal = body.some(s =>
        s.type === "LocalStatement" &&
        s.variables?.some(v => v.name === "valid")
    )
    if (hasValidLocal) return true
    // Fallback: do block besar yang mengandung repeat...until dan banyak statement
    if (body.length > 5) {
        const hasRepeat = body.some(s => s.type === "RepeatStatement")
        const hasIf = body.some(s => s.type === "IfStatement")
        if (hasRepeat || hasIf) return true
    }
    return false
}

// ── Deteksi apakah statement adalah prometheus VM (payload utama) ─────────────
// Bentuknya: return (function(...) ... end)(...) ATAU CallStatement dengan FunctionDeclaration
function isPrometheusVM(stat) {
    // ReturnStatement dengan CallExpression(FunctionDeclaration, ...)
    if (stat.type === "ReturnStatement") {
        const arg = stat.arguments?.[0]
        if (is(arg, { type: "CallExpression", base: { type: "FunctionDeclaration" } })) return true
    }
    // CallStatement dengan CallExpression(FunctionDeclaration, ...)
    if (stat.type === "CallStatement") {
        const expr = stat.expression
        if (is(expr, { type: "CallExpression", base: { type: "FunctionDeclaration" } })) return true
    }
    return false
}

// ── Main strip function ────────────────────────────────────────────────────────
function stripWRD(src) {
    let ast
    try {
        ast = parse(src, { ...defaultOptions, luaVersion: "5.1", encodingMode: "x-user-defined" })
    } catch (e) {
        throw new Error("parse failed: " + e.message)
    }

    const body = ast.body

    // Strategy 1: Cari index payload berdasarkan struktur prometheus
    // Skipping: Watermark, WatermarkCheck, AntiTamper → ambil sisanya
    let payloadStart = -1

    // Cari dari awal, skip statement WRD
    for (let i = 0; i < body.length; i++) {
        const stat = body[i]
        if (isWatermarkStatement(stat)) continue
        if (isWatermarkCheckStatement(stat)) continue
        if (isAntiTamperDoBlock(stat)) continue
        // Ini adalah payload pertama yang bukan WRD boilerplate
        payloadStart = i
        break
    }

    // Strategy 2: Cari langsung prometheus VM (return (function(...)...end)(...))
    let vmIndex = -1
    for (let i = 0; i < body.length; i++) {
        if (isPrometheusVM(body[i])) {
            vmIndex = i
            break
        }
    }

    // Pilih strategy terbaik
    let payloadNodes = null

    if (vmIndex >= 0) {
        // Ambil dari VM statement ke akhir (termasuk semua setelah VM)
        payloadNodes = body.slice(vmIndex)
    } else if (payloadStart >= 0) {
        payloadNodes = body.slice(payloadStart)
    }

    // Hapus trailing watermark assignment jika ada
    if (payloadNodes && payloadNodes.length > 1) {
        // Buang statement terakhir jika itu watermark gsub atau assignment
        const last = payloadNodes[payloadNodes.length - 1]
        if (isWatermarkStatement(last) || isWatermarkAssignment(last)) {
            payloadNodes = payloadNodes.slice(0, -1)
        }
    }

    if (!payloadNodes || payloadNodes.length === 0) {
        throw new Error("Could not locate prometheus VM payload in WRD output")
    }

    // Strategy 3: Fallback - jika hanya 1 DoStatement besar, ambil isinya
    if (payloadNodes.length === 1 && payloadNodes[0].type === "DoStatement") {
        const innerBody = payloadNodes[0].body || []
        // Cari VM di dalam do block
        for (let i = 0; i < innerBody.length; i++) {
            if (isPrometheusVM(innerBody[i])) {
                payloadNodes = innerBody.slice(i)
                break
            }
        }
        if (payloadNodes.length === 0) {
            payloadNodes = innerBody.filter(s => s && s.type)
        }
    }

    // Beautify payload
    let payloadSrc
    try {
        payloadSrc = beautify({ type: "Chunk", body: payloadNodes }).trim()
    } catch (e) {
        throw new Error("beautify failed: " + e.message)
    }

    if (!payloadSrc || payloadSrc.length < 10) {
        throw new Error("Extracted payload is empty or too short")
    }

    return payloadSrc
}

// ── Regex fallback jika AST parse gagal ───────────────────────────────────────
function regexFallback(src) {
    const lines = src.split("\n")

    // Cari baris pertama yang mengandung prometheus VM signature
    // Pattern: return (function(...) atau local function + VM pattern
    const vmPatterns = [
        /^\s*return\s+\(function\s*\(/, 
        /^\s*return\s+\w+\s*\(\s*function\s*\(/,
        /^\s*\w+\s*\(\s*function\s*\(/,
    ]

    let startLine = -1
    for (let i = 0; i < lines.length; i++) {
        if (vmPatterns.some(p => p.test(lines[i]))) {
            startLine = i
            break
        }
    }

    if (startLine >= 0) {
        return lines.slice(startLine).join("\n").trim()
    }

    // Fallback: buang baris WRD boilerplate dari awal
    // Skip baris-baris dengan pola WRD anti-tamper
    const skipPatterns = [
        /^\s*do\s+local\s+valid\s*=/,
        /repeat\s+until\s+valid/,
        /if\s+\w+\s*~=\s*["']/,
        /local\s+sethook\s*=/,
        /local\s+allowedLine\s*=/,
    ]

    let inAntitamper = 0
    const result = []
    for (const line of lines) {
        if (skipPatterns.some(p => p.test(line))) {
            inAntitamper++
            continue
        }
        if (inAntitamper > 0 && /^\s*end\s*$/.test(line)) {
            inAntitamper--
            continue
        }
        result.push(line)
    }

    const out = result.join("\n").trim()
    return out.length > 10 ? out : null
}

// ── Entry ──────────────────────────────────────────────────────────────────────
try {
    const src = fs.readFileSync(inp, "utf8")
    let payloadSrc

    try {
        payloadSrc = stripWRD(src)
    } catch (e) {
        // Coba regex fallback
        payloadSrc = regexFallback(src)
        if (!payloadSrc) throw e
    }

    fs.writeFileSync(out, payloadSrc + "\n")
    process.stdout.write(`OK|${Math.floor(performance.now())}|${Buffer.byteLength(payloadSrc)}\n`)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}

module.exports = { stripWRD }
