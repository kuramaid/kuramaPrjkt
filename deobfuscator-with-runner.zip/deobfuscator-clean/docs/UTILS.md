# Utilities Module Documentation

This directory contains utility functions used throughout the deobfuscation process.

## Modules

### helper.js
**Purpose**: General helper functions for AST manipulation and analysis.

**Key Functions**:
- `is(node, type)` - Check if AST node is of specific type
- `search(ast, predicate)` - Search AST for nodes matching predicate
- `searchIs(ast, type)` - Search for nodes of specific type
- `print(value)` - Debug printing utility

---

### ast.js
**Purpose**: Advanced AST manipulation and traversal utilities.

**Features**:
- AST node creation
- Tree traversal helpers
- Node type checking
- Parent-child relationship handling

---

### simple-ast.js
**Purpose**: Simplified AST operations for common patterns.

**Features**:
- Quick AST node creation
- Common pattern matching
- Simplified node transformations

---

### query.js
**Purpose**: Query and filter AST nodes efficiently.

**Features**:
- XPath-like queries for AST
- Complex node filtering
- Pattern matching
- Bulk node selection

**Example**:
```javascript
const query = require('./query');
// Find all function declarations
const functions = query(ast, 'FunctionDeclaration');
```

---

### functions.js
**Purpose**: Function-specific utilities for analysis and transformation.

**Features**:
- Function signature analysis
- Parameter extraction
- Function call detection
- Closure handling

---

### indexCleaner.js
**Purpose**: Cleans up array/table index access patterns.

**Features**:
- Simplifies complex index expressions
- Converts computed indices to literals where possible

**Example**:
```lua
-- Before: arr[1 + 0]
-- After:  arr[1]
```

---

### indexFixer.js
**Purpose**: Fixes incorrect or obfuscated index patterns.

**Features**:
- Corrects off-by-one errors
- Normalizes index access
- Handles mixed index types

---

### localify.js
**Purpose**: Converts global variables to local where appropriate.

**Features**:
- Scope analysis
- Variable usage tracking
- Global to local conversion

**Benefits**:
- Improves code readability
- Better variable scoping
- Easier to understand variable lifetime

---

### repeatfix.js
**Purpose**: Fixes repeat-until statement patterns.

**Features**:
- Detects malformed repeat statements
- Converts to standard patterns
- Simplifies loop conditions

---

## Common Usage Patterns

### Searching AST
```javascript
const { search, is } = require('./helper');

// Find all local assignments
const locals = search(ast, node => 
  is(node, 'LocalStatement')
);
```

### Querying Nodes
```javascript
const query = require('./query');

// Complex queries
const results = query(ast, {
  type: 'CallExpression',
  base: { name: 'print' }
});
```

### Index Operations
```javascript
const indexFixer = require('./indexFixer');
const indexCleaner = require('./indexCleaner');

// Clean and fix indices
ast = indexCleaner(ast);
ast = indexFixer(ast);
```

## Integration

These utilities are designed to work together and are heavily used by the deobfuscation modules. Most modules import multiple utilities:

```javascript
const { is, search, print } = require('../utils/helper');
const query = require('../utils/query');
const { localify } = require('../utils/localify');
```

## Performance Notes

- `search()` performs full AST traversal - use sparingly in hot paths
- `query()` is optimized for multiple node selection
- Cache results when possible to avoid redundant traversals
