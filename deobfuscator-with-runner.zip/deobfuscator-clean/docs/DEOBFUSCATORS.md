# Deobfuscators Module Documentation

This directory contains the core deobfuscation modules that handle specific obfuscation techniques.

## Modules

### decrypt.js
**Purpose**: Handles decryption of encrypted strings in obfuscated Lua code.

**Features**:
- Decrypts string literals
- Resolves encrypted function names
- Handles various encryption schemes

**Usage**:
```javascript
const decrypt = require('./decrypt');
// Use decrypt functions
```

---

### cleaner.js
**Purpose**: Removes dead code and unnecessary constructs from deobfuscated code.

**Features**:
- Removes unused variables
- Eliminates dead code branches
- Simplifies redundant constructs

---

### constarray.js
**Purpose**: Reconstructs and simplifies constant arrays used in obfuscation.

**Features**:
- Identifies constant array patterns
- Inlines array values at usage points
- Removes array declarations after inlining

**Common Pattern**:
```lua
-- Obfuscated
local arr = {10, 20, 30}
local x = arr[1] -- becomes: local x = 10
```

---

### uncff.js
**Purpose**: Unflattens control flow obfuscation (Control Flow Flattening reversal).

**Features**:
- Detects state machine patterns
- Reconstructs original control flow
- Simplifies switch-case obfuscation

**Handles**:
- State variable based control flow
- Switch/case dispatch tables
- Opaque predicates

---

### inlinev4.js
**Purpose**: Inlines variables and function calls to restore readable code.

**Features**:
- Variable inlining
- Function call inlining
- Constant propagation
- Expression simplification

**Example**:
```lua
-- Before
local a = 5
local b = a + 3
print(b)

-- After
print(8)
```

---

### optimize.js
**Purpose**: Optimizes deobfuscated code for better readability.

**Features**:
- Simplifies expressions
- Combines statements where possible
- Removes redundant operations
- Improves variable naming

---

## Processing Pipeline

The typical deobfuscation pipeline:

1. **Parse** → Convert code to AST
2. **Decrypt** → Decrypt strings (decrypt.js)
3. **Unflatten** → Restore control flow (uncff.js)
4. **Inline** → Inline variables/constants (inlinev4.js)
5. **Reconstruct** → Handle constant arrays (constarray.js)
6. **Clean** → Remove dead code (cleaner.js)
7. **Optimize** → Final optimization (optimize.js)
8. **Beautify** → Format output

## Notes

- These modules work with AST (Abstract Syntax Tree) representations
- Order of execution matters for best results
- Some modules may need multiple passes for complete deobfuscation
