# Project Structure

Complete file structure of the Lua Deobfuscator project.

```
deobfuscator-clean/
│
├── README.md                    # Main project documentation
├── package.json                 # Node.js package configuration
├── .gitignore                   # Git ignore rules
│
├── src/                         # Source code
│   ├── core/                    # Core deobfuscation logic
│   │   └── main.js              # Main entry point
│   │
│   ├── deobfuscators/           # Deobfuscation modules
│   │   ├── decrypt.js           # String decryption
│   │   ├── cleaner.js           # Dead code removal
│   │   ├── constarray.js        # Constant array handling
│   │   ├── uncff.js             # Control flow unflattening
│   │   ├── inlinev4.js          # Variable/function inlining
│   │   └── optimize.js          # Code optimization
│   │
│   ├── parsers/                 # Parsing and formatting
│   │   ├── luaparse.js          # Lua AST parser
│   │   ├── beautifier.js        # JavaScript code beautifier
│   │   ├── lua_beautifier.js    # Lua code beautifier
│   │   ├── lua_deobf.js         # Lua deobfuscation utilities
│   │   └── minify.js            # Code minification
│   │
│   ├── utils/                   # Utility functions
│   │   ├── helper.js            # General helper functions
│   │   ├── ast.js               # AST manipulation
│   │   ├── simple-ast.js        # Simplified AST operations
│   │   ├── query.js             # AST querying
│   │   ├── functions.js         # Function utilities
│   │   ├── indexCleaner.js      # Index cleaning
│   │   ├── indexFixer.js        # Index fixing
│   │   ├── localify.js          # Local variable conversion
│   │   └── repeatfix.js         # Repeat statement fixes
│   │
│   └── exploit_types.d.luau     # Luau type definitions
│
├── lua/                         # Lua scripts and frameworks
│   ├── obfuscators/             # Obfuscation scripts (reference)
│   │   ├── AddVararg.lua        # Adds vararg to functions
│   │   ├── AntiTamper.lua       # Anti-tampering protection
│   │   ├── ConstantArray.lua    # Constant array obfuscation
│   │   ├── EncryptStrings.lua   # String encryption
│   │   ├── NumbersToExpressions.lua # Number obfuscation
│   │   ├── ProxifyLocals.lua    # Local variable proxying
│   │   ├── SplitStrings.lua     # String splitting
│   │   ├── Vmify.lua            # VM-based obfuscation
│   │   ├── Watermark.lua        # Code watermarking
│   │   ├── WatermarkCheck.lua   # Watermark verification
│   │   └── WrapInFunction.lua   # Function wrapping
│   │
│   └── prometheus/              # Prometheus obfuscator framework
│       ├── cli.lua              # Command-line interface
│       ├── colors.lua           # Color output utilities
│       ├── config.lua           # Configuration
│       ├── highlightlua.lua     # Lua syntax highlighting
│       ├── logger.lua           # Logging utilities
│       ├── presets.lua          # Obfuscation presets
│       ├── prometheus.lua       # Main framework file
│       └── prometheus/          # Core engine
│           ├── compiler/        # Code compilation
│           │   ├── expressions/ # Expression handling
│           │   └── statements/  # Statement handling
│           ├── namegenerators/  # Name generation strategies
│           ├── steps/           # Obfuscation steps
│           │   ├── AddVararg.lua
│           │   ├── AntiTamper.lua
│           │   ├── ConstantArray.lua
│           │   ├── EncryptStrings.lua
│           │   ├── NumbersToExpressions.lua
│           │   ├── ProxifyLocals.lua
│           │   ├── SplitStrings.lua
│           │   ├── Vmify.lua
│           │   ├── Watermark.lua
│           │   ├── WatermarkCheck.lua
│           │   └── WrapInFunction.lua
│           ├── enums.lua        # Enumeration definitions
│           ├── parser.lua       # Lua parser
│           ├── pipeline.lua     # Processing pipeline
│           ├── randomLiterals.lua # Random literal generation
│           ├── randomStrings.lua  # Random string generation
│           ├── scope.lua        # Scope management
│           ├── step.lua         # Base step class
│           ├── steps.lua        # Step collection
│           ├── tokenizer.lua    # Tokenization
│           ├── unparser.lua     # AST to code conversion
│           ├── util.lua         # Utilities
│           └── visitast.lua     # AST visitor pattern
│
├── config/                      # Configuration files
│   ├── config.js                # JavaScript configuration
│   └── .luaurc                  # Luau configuration
│
├── bin/                         # Binary executables
│   ├── lune.exe                 # Lune runtime
│   └── lute.exe                 # Lute tool
│
└── docs/                        # Documentation
    ├── DEOBFUSCATORS.md         # Deobfuscator modules guide
    ├── UTILS.md                 # Utilities guide
    └── STRUCTURE.md             # This file

```

## File Count Summary

- **JavaScript files**: ~24 core deobfuscation modules
- **Lua files**: ~90+ including Prometheus framework
- **Documentation**: 5 markdown files
- **Configuration**: 3 configuration files
- **Binaries**: 2 executables

## Module Dependencies

### Core Dependencies
```
main.js
  ├── parsers/beautifier.js
  ├── parsers/luaparse.js
  ├── utils/simple-ast.js
  ├── deobfuscators/inlinev4.js
  ├── utils/localify.js
  ├── utils/helper.js
  ├── utils/indexCleaner.js
  ├── utils/indexFixer.js
  └── utils/query.js
```

### Deobfuscator Modules
- Each deobfuscator typically imports from `utils/helper.js`
- Most use `parsers/luaparse.js` for AST operations
- Cross-dependencies between deobfuscators are minimal

## Key Design Patterns

1. **Modular Architecture**: Each deobfuscation technique is isolated in its own module
2. **AST-Based**: All transformations work on Abstract Syntax Trees
3. **Utility-First**: Common operations centralized in utils/
4. **Parser Independence**: Parsers separated from transformation logic
5. **Reference Implementation**: Lua obfuscators included for understanding patterns

## Notes

- All import paths have been updated to reflect new structure
- Removed ~15 unused/deprecated files
- Binary executables preserved in bin/ directory
- Prometheus framework kept intact for reference
