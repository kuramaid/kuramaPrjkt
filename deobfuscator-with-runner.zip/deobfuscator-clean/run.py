#!/usr/bin/env python3
import os
import sys
import subprocess
import shutil
import json
import time
from pathlib import Path

BASE_DIR = Path(__file__).parent.resolve()
MAIN_JS = BASE_DIR / "src" / "core" / "main.js"
BEAUTIFIER_JS = BASE_DIR / "src" / "parsers" / "lua_beautifier.js"
MINIFY_JS = BASE_DIR / "src" / "parsers" / "minify.js"
NODE_MODULES = BASE_DIR / "node_modules"

R = "\033[91m"
G = "\033[92m"
Y = "\033[93m"
B = "\033[94m"
C = "\033[96m"
W = "\033[97m"
DIM = "\033[2m"
BOLD = "\033[1m"
RST = "\033[0m"

def clear():
    os.system("clear")

def pr(text=""):
    print(text)

def title():
    clear()
    print(f"{B}{BOLD}")
    print("  ██████╗ ███████╗ ██████╗ ██████╗ ███████╗")
    print("  ██╔══██╗██╔════╝██╔═══██╗██╔══██╗██╔════╝")
    print("  ██║  ██║█████╗  ██║   ██║██████╔╝█████╗  ")
    print("  ██║  ██║██╔══╝  ██║   ██║██╔══██╗██╔══╝  ")
    print("  ██████╔╝███████╗╚██████╔╝██████╔╝██║     ")
    print("  ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ")
    print(f"{RST}{C}          Lua Deobfuscator v1.0 | KuramaMods{RST}")
    print(f"{DIM}  ─────────────────────────────────────────────{RST}")
    pr()

def ok(msg):
    print(f"  {G}✓{RST} {msg}")

def err(msg):
    print(f"  {R}✗{RST} {msg}")

def info(msg):
    print(f"  {Y}→{RST} {msg}")

def prompt(msg):
    return input(f"  {C}›{RST} {msg}").strip()

def check_node():
    return shutil.which("node") is not None

def check_npm():
    return shutil.which("npm") is not None

def get_node_version():
    try:
        r = subprocess.run(["node", "--version"], capture_output=True, text=True)
        return r.stdout.strip()
    except:
        return None

def install_deps():
    title()
    info("Memeriksa dependensi...")
    pr()

    if not check_node():
        err("Node.js tidak ditemukan!")
        pr()
        info("Install Node.js di Termux/Ubuntu proot:")
        print(f"  {DIM}pkg install nodejs{RST}  atau  {DIM}apt install nodejs npm{RST}")
        pr()
        input(f"  {Y}Tekan Enter untuk keluar...{RST}")
        sys.exit(1)

    ok(f"Node.js ditemukan: {get_node_version()}")

    if not check_npm():
        err("npm tidak ditemukan!")
        pr()
        info("Install npm: apt install npm")
        input(f"  {Y}Tekan Enter untuk keluar...{RST}")
        sys.exit(1)

    ok("npm ditemukan")

    if not NODE_MODULES.exists():
        pr()
        info("Menginstall npm dependencies...")
        pr()
        r = subprocess.run(
            ["npm", "install"],
            cwd=BASE_DIR,
            text=True
        )
        pr()
        if r.returncode == 0:
            ok("Dependencies berhasil diinstall!")
        else:
            err("Gagal install dependencies!")
            input(f"  {Y}Tekan Enter untuk lanjut...{RST}")
    else:
        ok("node_modules sudah ada")

    pr()
    ok("Semua siap!")
    time.sleep(1)

def run_node(script_args, capture=False):
    cmd = ["node"] + script_args
    if capture:
        r = subprocess.run(cmd, cwd=BASE_DIR, capture_output=True, text=True)
        return r.returncode, r.stdout, r.stderr
    else:
        r = subprocess.run(cmd, cwd=BASE_DIR)
        return r.returncode, "", ""

def validate_lua_file(path):
    p = Path(path)
    if not p.exists():
        return False, f"File tidak ditemukan: {path}"
    if p.suffix.lower() not in [".lua", ".luau", ".txt"]:
        return False, f"Bukan file Lua: {path}"
    return True, ""

def menu_deobfuscate():
    title()
    print(f"  {BOLD}{W}[ DEOBFUSCATE ]{RST}")
    pr()
    info("Masukkan path file Lua yang ingin di-deobfuscate")
    pr()

    inp = prompt("Input file (.lua): ")
    if not inp:
        return

    valid, msg = validate_lua_file(inp)
    if not valid:
        err(msg)
        input(f"\n  {Y}Tekan Enter...{RST}")
        return

    inp_path = Path(inp).resolve()
    default_out = inp_path.parent / (inp_path.stem + "_deobf.lua")
    pr()
    out = prompt(f"Output file [{default_out.name}]: ")
    if not out:
        out = str(default_out)

    out_path = Path(out)
    if not out_path.is_absolute():
        out_path = inp_path.parent / out_path

    pr()
    info("Mode tambahan (kosongkan = default):")
    print(f"  {DIM}[1] Simpan formatted.lua sebelum deobf{RST}")
    print(f"  {DIM}[2] Skip inlining & localify{RST}")
    pr()
    mode = prompt("Mode [1/2/kosong]: ")

    args = [str(MAIN_JS), str(inp_path), str(out_path)]

    if mode == "1":
        args += ["", "true"]
    elif mode == "2":
        args += ["", "", "true"]

    pr()
    info(f"Memproses: {inp_path.name} ...")
    pr()
    print(f"  {DIM}{'─'*45}{RST}")

    start = time.time()
    code, stdout, stderr = run_node(args, capture=False)
    elapsed = time.time() - start

    print(f"  {DIM}{'─'*45}{RST}")
    pr()

    if code == 0:
        ok(f"Selesai dalam {elapsed:.2f}s")
        ok(f"Output: {out_path}")
    else:
        err(f"Gagal (exit code {code})")

    pr()
    input(f"  {Y}Tekan Enter untuk kembali...{RST}")

def menu_beautify():
    title()
    print(f"  {BOLD}{W}[ BEAUTIFY LUA ]{RST}")
    pr()
    info("Format/beautify kode Lua")
    pr()

    inp = prompt("Input file (.lua): ")
    if not inp:
        return

    valid, msg = validate_lua_file(inp)
    if not valid:
        err(msg)
        input(f"\n  {Y}Tekan Enter...{RST}")
        return

    inp_path = Path(inp).resolve()
    default_out = inp_path.parent / (inp_path.stem + "_formatted.lua")
    pr()
    out = prompt(f"Output file [{default_out.name}]: ")
    if not out:
        out = str(default_out)

    out_path = Path(out)
    if not out_path.is_absolute():
        out_path = inp_path.parent / out_path

    script = f"""
const fs = require('fs');
const beautify = require({json.dumps(str(BASE_DIR / 'src/parsers/lua_beautifier.js'))});
const src = fs.readFileSync({json.dumps(str(inp_path))}, 'utf8');
const result = beautify(src);
fs.writeFileSync({json.dumps(str(out_path))}, result);
console.log('Done. Output: ' + {json.dumps(str(out_path))});
"""
    tmp = BASE_DIR / "_tmp_beautify.js"
    tmp.write_text(script)

    pr()
    info("Beautifying...")
    code, _, _ = run_node([str(tmp)], capture=False)
    tmp.unlink(missing_ok=True)

    pr()
    if code == 0:
        ok(f"Output: {out_path}")
    else:
        err("Gagal beautify")

    pr()
    input(f"  {Y}Tekan Enter untuk kembali...{RST}")

def menu_minify():
    title()
    print(f"  {BOLD}{W}[ MINIFY LUA ]{RST}")
    pr()
    info("Minify kode Lua (hapus whitespace/komentar)")
    pr()

    inp = prompt("Input file (.lua): ")
    if not inp:
        return

    valid, msg = validate_lua_file(inp)
    if not valid:
        err(msg)
        input(f"\n  {Y}Tekan Enter...{RST}")
        return

    inp_path = Path(inp).resolve()
    default_out = inp_path.parent / (inp_path.stem + "_min.lua")
    pr()
    out = prompt(f"Output file [{default_out.name}]: ")
    if not out:
        out = str(default_out)

    out_path = Path(out)
    if not out_path.is_absolute():
        out_path = inp_path.parent / out_path

    script = f"""
const fs = require('fs');
const minify = require({json.dumps(str(BASE_DIR / 'src/parsers/minify.js'))});
const src = fs.readFileSync({json.dumps(str(inp_path))}, 'utf8');
const result = minify(src);
fs.writeFileSync({json.dumps(str(out_path))}, result);
const orig = Buffer.byteLength(src, 'utf8');
const mini = Buffer.byteLength(result, 'utf8');
const pct = ((1 - mini/orig)*100).toFixed(1);
console.log('Done! ' + orig + ' → ' + mini + ' bytes (' + pct + '% smaller)');
"""
    tmp = BASE_DIR / "_tmp_minify.js"
    tmp.write_text(script)

    pr()
    info("Minifying...")
    code, _, _ = run_node([str(tmp)], capture=False)
    tmp.unlink(missing_ok=True)

    pr()
    if code == 0:
        ok(f"Output: {out_path}")
    else:
        err("Gagal minify")

    pr()
    input(f"  {Y}Tekan Enter untuk kembali...{RST}")

def menu_batch():
    title()
    print(f"  {BOLD}{W}[ BATCH DEOBFUSCATE ]{RST}")
    pr()
    info("Deobfuscate semua .lua di dalam folder")
    pr()

    folder = prompt("Folder input: ")
    if not folder:
        return

    folder_path = Path(folder).resolve()
    if not folder_path.is_dir():
        err(f"Folder tidak ditemukan: {folder}")
        input(f"\n  {Y}Tekan Enter...{RST}")
        return

    files = list(folder_path.glob("*.lua")) + list(folder_path.glob("*.luau"))
    if not files:
        err("Tidak ada file .lua/.luau di folder tersebut")
        input(f"\n  {Y}Tekan Enter...{RST}")
        return

    pr()
    info(f"Ditemukan {len(files)} file:")
    for f in files:
        print(f"  {DIM}· {f.name}{RST}")

    pr()
    out_folder = prompt(f"Folder output [{folder_path}/output]: ")
    if not out_folder:
        out_folder = folder_path / "output"
    else:
        out_folder = Path(out_folder)

    out_folder = Path(out_folder)
    out_folder.mkdir(parents=True, exist_ok=True)

    pr()
    ok_count = 0
    fail_count = 0

    for f in files:
        out_file = out_folder / (f.stem + "_deobf.lua")
        info(f"Processing: {f.name}")
        code, _, _ = run_node([str(MAIN_JS), str(f), str(out_file)], capture=False)
        if code == 0:
            ok_count += 1
            ok(f"  → {out_file.name}")
        else:
            fail_count += 1
            err(f"  → Gagal: {f.name}")
        pr()

    print(f"  {DIM}{'─'*45}{RST}")
    ok(f"Berhasil: {ok_count}/{len(files)}")
    if fail_count:
        err(f"Gagal: {fail_count}/{len(files)}")
    ok(f"Output folder: {out_folder}")

    pr()
    input(f"  {Y}Tekan Enter untuk kembali...{RST}")

def menu_info():
    title()
    print(f"  {BOLD}{W}[ INFO SISTEM ]{RST}")
    pr()

    node_ver = get_node_version() or "Tidak ditemukan"
    npm_ver = "Tidak ditemukan"
    try:
        r = subprocess.run(["npm", "--version"], capture_output=True, text=True)
        npm_ver = r.stdout.strip()
    except:
        pass

    deps_ok = NODE_MODULES.exists()

    src_files = list((BASE_DIR / "src").rglob("*.js")) if (BASE_DIR / "src").exists() else []

    print(f"  {C}Node.js  :{RST} {node_ver}")
    print(f"  {C}npm      :{RST} {npm_ver}")
    print(f"  {C}Deps     :{RST} {'✓ Terinstall' if deps_ok else '✗ Belum install'}")
    print(f"  {C}JS files :{RST} {len(src_files)} file")
    print(f"  {C}Base dir :{RST} {BASE_DIR}")
    pr()

    print(f"  {BOLD}Pipeline Deobfuscation:{RST}")
    steps = [
        ("Parser", "luaparse.js → AST"),
        ("Beautifier", "Normalize kode"),
        ("ConstArray", "Inline constant arrays"),
        ("Uncff", "Unflatten control flow"),
        ("InlineV4", "Inline variabel & fungsi"),
        ("Decrypt", "Decrypt encrypted strings"),
        ("Cleaner", "Hapus dead code"),
        ("Localify", "Konversi ke local vars"),
        ("Output", "lua_beautifier.js → file"),
    ]
    for i, (name, desc) in enumerate(steps):
        arrow = "└" if i == len(steps)-1 else "├"
        print(f"  {DIM}{arrow}── {G}{name:<12}{RST}{DIM}{desc}{RST}")

    pr()
    input(f"  {Y}Tekan Enter untuk kembali...{RST}")

def menu_reinstall():
    title()
    print(f"  {BOLD}{W}[ REINSTALL DEPENDENCIES ]{RST}")
    pr()
    info("Hapus node_modules dan install ulang")
    pr()
    confirm = prompt("Lanjutkan? [y/N]: ")
    if confirm.lower() != 'y':
        return

    pr()
    if NODE_MODULES.exists():
        info("Menghapus node_modules...")
        shutil.rmtree(NODE_MODULES)
        ok("Dihapus")

    pr()
    info("Menginstall ulang...")
    pr()
    r = subprocess.run(["npm", "install"], cwd=BASE_DIR)
    pr()
    if r.returncode == 0:
        ok("Berhasil reinstall!")
    else:
        err("Gagal reinstall")

    pr()
    input(f"  {Y}Tekan Enter untuk kembali...{RST}")

def main():
    install_deps()

    while True:
        title()
        print(f"  {BOLD}MENU UTAMA{RST}")
        pr()
        print(f"  {G}[1]{RST} Deobfuscate file Lua")
        print(f"  {G}[2]{RST} Beautify / Format kode Lua")
        print(f"  {G}[3]{RST} Minify kode Lua")
        print(f"  {G}[4]{RST} Batch deobfuscate (folder)")
        print(f"  {G}[5]{RST} Info sistem & pipeline")
        print(f"  {G}[6]{RST} Reinstall dependencies")
        print(f"  {R}[0]{RST} Keluar")
        pr()

        choice = prompt("Pilih menu: ")

        if choice == "1":
            menu_deobfuscate()
        elif choice == "2":
            menu_beautify()
        elif choice == "3":
            menu_minify()
        elif choice == "4":
            menu_batch()
        elif choice == "5":
            menu_info()
        elif choice == "6":
            menu_reinstall()
        elif choice == "0":
            title()
            print(f"  {C}Bye!{RST}")
            pr()
            sys.exit(0)
        else:
            err("Pilihan tidak valid")
            time.sleep(0.8)

if __name__ == "__main__":
    main()
