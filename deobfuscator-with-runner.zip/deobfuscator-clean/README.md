# Lua Deobfuscator

A comprehensive Lua code deobfuscator tool that can reverse various obfuscation techniques.

## 📁 Project Structure

```
deobfuscator-clean/
├── src/
│   ├── core/           # Main deobfuscation entry point
│   │   └── main.js     # Primary deobfuscation logic
│   ├── deobfuscators/  # Specific deobfuscation modules
│   │   ├── decrypt.js       # String decryption
│   │   ├── cleaner.js       # Code cleaning
│   │   ├── constarray.js    # Constant array handling
│   │   ├── uncff.js         # Control flow unflattening
│   │   ├── inlinev4.js      # Variable/function inlining
│   │   └── optimize.js      # Code optimization
│   ├── parsers/        # Parsing and formatting
│   │   ├── luaparse.js      # Lua AST parser
│   │   ├── beautifier.js    # JS code beautifier
│   │   ├── lua_beautifier.js # Lua code beautifier
│   │   ├── lua_deobf.js     # Lua deobfuscation utilities
│   │   └── minify.js        # Code minification
│   └── utils/          # Utility functions
│       ├── helper.js        # General helpers
│       ├── ast.js           # AST manipulation
│       ├── simple-ast.js    # Simplified AST operations
│       ├── query.js         # AST querying
│       ├── functions.js     # Function utilities
│       ├── indexCleaner.js  # Index cleaning
│       ├── indexFixer.js    # Index fixing
│       ├── localify.js      # Local variable conversion
│       └── repeatfix.js     # Repeat statement fixes
├── lua/
│   ├── obfuscators/    # Lua obfuscation scripts (for reference)
│   │   ├── AddVararg.lua
│   │   ├── AntiTamper.lua
│   │   ├── ConstantArray.lua
│   │   ├── EncryptStrings.lua
│   │   ├── NumbersToExpressions.lua
│   │   ├── ProxifyLocals.lua
│   │   ├── SplitStrings.lua
│   │   ├── Vmify.lua
│   │   ├── Watermark.lua
│   │   ├── WatermarkCheck.lua
│   │   └── WrapInFunction.lua
│   └── prometheus/     # Prometheus obfuscator framework
│       └── prometheus/ # Core prometheus engine
├── config/             # Configuration files
│   ├── config.js       # Main configuration
│   └── .luaurc         # Luau configuration
├── bin/                # Binary executables
│   ├── lune.exe        # Lune runtime
│   └── lute.exe        # Lute tool
└── docs/               # Documentation

```

## 🚀 Features

- **String Decryption**: Decrypt obfuscated strings
- **Control Flow Unflattening**: Restore original control flow
- **Variable Inlining**: Inline obfuscated variables and constants
- **Constant Array Restoration**: Reconstruct constant arrays
- **Code Cleaning**: Remove dead code and unnecessary constructs
- **Code Beautification**: Format and beautify output
- **AST-based Processing**: Uses Abstract Syntax Tree for accurate transformations

## 🔧 Deobfuscation Techniques

### Supported Obfuscation Types

1. **String Encryption** - `EncryptStrings.lua`
2. **String Splitting** - `SplitStrings.lua`
3. **Control Flow Obfuscation** - `uncff.js`
4. **Constant Arrays** - `ConstantArray.lua` / `constarray.js`
5. **Local Variable Proxying** - `ProxifyLocals.lua`
6. **VM-based Obfuscation** - `Vmify.lua`
7. **Watermarking** - `Watermark.lua` / `WatermarkCheck.lua`
8. **Vararg Addition** - `AddVararg.lua`
9. **Function Wrapping** - `WrapInFunction.lua`

## 📖 Usage

### Basic Usage

```javascript
const deobfuscate = require('./src/core/main');

// Deobfuscate a file
await deobfuscate('input.lua', 'output.lua');
```

### Module Usage

```javascript
// Individual modules can be used separately
const decrypt = require('./src/deobfuscators/decrypt');
const cleaner = require('./src/deobfuscators/cleaner');
const beautify = require('./src/parsers/lua_beautifier');
```

## 🗑️ Removed Files

The following files were removed during cleanup as they are deprecated, testing-related, or unrelated to core functionality:

### Deprecated/Old Versions
- `decrypt_old.js` - Old version of decryption module
- `inlinev3.js` - Old version (v4 is current)
- `oldm` - Backup/old file

### Discord Bot Related
- `db.js` - Database configuration
- `embed_builder.js` - Discord embed builder
- `img.js` - Image handling for Discord
- `inviter.js` - Discord invite functionality
- `request.js` - HTTP request utility

### Test/Development Files
- `test.lua` - Test script
- `meow.lua` - Test/demo file
- `macros.lua` - Empty macro file

### Other
- `obf.js` - Obfuscator (not deobfuscator)
- `medal.exe` - Unrelated executable

## 🛠️ Dependencies

- Node.js
- luau-web (for Lua execution)
- luaparse (for AST parsing)

## 📝 Notes

- All import paths in `main.js` need to be updated to reflect the new structure
- Binary executables (lune.exe, lute.exe) are included in the `bin/` folder
- Prometheus obfuscator framework is included for reference and understanding obfuscation patterns

## ⚠️ Important

This tool is for educational and legitimate security research purposes only. Always ensure you have proper authorization before deobfuscating code.

## 📄 License

Please refer to the original license of the source code.
