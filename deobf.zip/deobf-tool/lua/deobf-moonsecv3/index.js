// deobf-moonsecv3/index.js
// Deobfuscate MoonSec V3 output
// Logic ported dari MoonsecDeobfuscator C# source (Deserializer, StringDecoding, Analyzer)

const fs = require("fs")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node index.js <input> <output>")
    process.exit(1)
}

// ── StringDecoding ─────────────────────────────────────────────────────────────

/**
 * Decode escape-encoded string: "\48\32\65..." → Buffer
 */
function decodeEscape(data) {
    const parts = data.split("\\").slice(1)
    return Buffer.from(parts.map(p => parseInt(p, 10)))
}

/**
 * Decode hex-encoded string with rolling key
 * - Pertama 16 char: alphabet/charset
 * - Sisanya: pairs of chars di-decode dengan key
 */
function decodeWithKey(data, key) {
    const chars = {}
    for (let i = 0; i < 16; i++) chars[data[i]] = i

    const result = []
    let rkey = key
    for (let i = 16; i < data.length; i += 2) {
        const c1 = data[i]
        const c2 = i + 1 < data.length ? data[i + 1] : "\0"
        const i1 = chars[c1] ?? 0
        const i2 = chars[c2] ?? 0
        result.push((i1 * 16 + i2 + rkey) % 256)
        rkey += key
    }
    return Buffer.from(result)
}

/**
 * Decode konstanta dari binary blob
 * Returns: Map<string, string[]>
 */
function decodeConstants(buf) {
    const constants = {}
    let pos = 0

    while (pos < buf.length) {
        let control = buf[pos++]
        if (control === 5) break
        if (control === 1) control = 2

        const size = buf[pos++]
        const first = buf.slice(pos, pos + size).toString("utf8")
        pos += size

        let value = null
        switch (control) {
            case 0: {
                const strSize = buf[pos++]
                const second = buf.slice(pos, pos + strSize).toString("utf8")
                pos += strSize
                value = [first, second]
                break
            }
            case 2:
            case 4:
            case 6:
                value = [first]
                break
            default:
                value = [first]
        }

        const keyBuf = buf.slice(pos, pos + 8)
        const key = keyBuf.toString("utf8")
        pos += 8

        if (value) constants[key] = value
    }
    return constants
}

/**
 * Decode satu string konstanta dari bytecode
 */
function decodeConstant(key, bytes) {
    if (bytes.length > 1 && bytes[0] > 0x7F) {
        const newBytes = Buffer.alloc(bytes.length - 1)
        for (let i = 1; i < bytes.length; i++)
            newBytes[i - 1] = (bytes[i] + key) % 256
        return newBytes.toString("utf8")
    }
    return bytes.toString("utf8")
}

// ── Lua Source Parser (regex-based, buat ambil encoded strings) ────────────────

/**
 * Cari semua call(key, encodedStr) dan standalone escape strings
 * Returns: Array<{ key: number|null, data: string }>
 */
function collectEncodedStrings(src) {
    const results = []

    // Pattern 1: func(123456, "...encoded...")
    // MoonSec V3 memanggil decryptor(numberKey, encodedString)
    const callPattern = /\w+\((\d+),\s*["']([\s\S]*?)["']\)/g
    let m
    while ((m = callPattern.exec(src)) !== null) {
        results.push({ key: parseInt(m[1]), data: m[2] })
    }

    // Pattern 2: standalone escape string "\48\32..."
    const escPattern = /"(\\(?:\d{1,3}\\?)+)"/g
    while ((m = escPattern.exec(src)) !== null) {
        if (m[1].startsWith("\\4") || m[1].startsWith("\\1")) {
            results.push({ key: null, data: m[1] })
        }
    }

    return results
}

// ── Constant Replacer ─────────────────────────────────────────────────────────

/**
 * Ganti semua reference ke constant table dengan nilai aslinya
 * Contoh: _["\x4b\x7a"] → "string.format"
 */
function applyConstantReplacements(src, constants) {
    let result = src

    for (const [k, vals] of Object.entries(constants)) {
        // Escape key untuk regex
        const escapedKey = k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")

        // Pattern: _["key"] atau _['key'] atau tbl["key"]
        const patterns = [
            new RegExp(`\\w+\\["${escapedKey}"\\]`, "g"),
            new RegExp(`\\w+\\['${escapedKey}'\\]`, "g"),
        ]

        const replacement = vals.join(".")

        for (const pat of patterns) {
            result = result.replace(pat, replacement)
        }
    }

    return result
}

// ── MoonSec V3 Bytecode Header Detection ─────────────────────────────────────

/**
 * Detect apakah src ini MoonSec V3
 */
function isMoonSecV3(src) {
    // MoonSec V3 signature: method call dengan "#" string arg
    return /\w+\.\w+\(["']#/.test(src) ||
           // Atau encoded string blob besar di awal
           /local\s+\w+\s*=\s*["'][\x00-\x7F]{100,}["']/.test(src)
}

// ── Anti-Tamper Handler ───────────────────────────────────────────────────────

/**
 * Cek apakah ada anti-tamper layer (lebih dari 3 statement di root)
 * MoonSec V3 kadang membungkus script asli dalam layer tambahan
 */
function detectAntiTamper(src) {
    // Hitung top-level statement
    const topLevelLocals = (src.match(/^local\s+\w+/gm) || []).length
    return topLevelLocals > 6
}

// ── Main Deobfuscation Pipeline ───────────────────────────────────────────────

function deobfuscate(src) {
    if (!isMoonSecV3(src))
        throw new Error("File tidak terdeteksi sebagai MoonSec V3")

    // Step 1: Kumpulkan encoded strings
    const encodedStrings = collectEncodedStrings(src)
    if (encodedStrings.length === 0)
        throw new Error("Tidak ada encoded string ditemukan")

    // Step 2: Decode semua encoded strings → kumpulkan semua constants
    let allConstants = {}
    for (const { key, data } of encodedStrings) {
        try {
            let bytes
            if (key === null) {
                bytes = decodeEscape(data)
            } else {
                bytes = decodeWithKey(data, key)
            }
            const decoded = decodeConstants(bytes)
            Object.assign(allConstants, decoded)
        } catch (_) {
            // skip entry yang gagal
        }
    }

    if (Object.keys(allConstants).length === 0)
        throw new Error("Gagal decode constants")

    // Step 3: Apply constant replacements ke source
    let result = applyConstantReplacements(src, allConstants)

    // Step 4: Clean up sisa obfuscation artifacts

    // Hapus deklarasi table konstanta (biasanya local _ = {})
    result = result.replace(/local\s+\w+\s*=\s*\{[\s\S]{0,200}\}/g, (match) => {
        // Hanya hapus kalau isinya terlihat seperti konstanta encoded
        if (/["'][\x00-\x1F]/.test(match) || match.split(",").length > 5)
            return "-- [moonsec constant table removed]"
        return match
    })

    // Hapus baris pemanggilan decoder function yang sudah tidak diperlukan
    result = result.replace(/\w+\(\d+,\s*["'][^"']{20,}["']\)/g, (match) => {
        // Hanya hapus kalau isinya sudah di-resolve (tidak ada lagi di result)
        return match // biarkan saja, sudah di-replace di step 3
    })

    // Step 5: Fold constant expressions sederhana
    // Contoh: (1 + 2) → 3, ("a" .. "b") → "ab"
    result = foldConstants(result)

    // Step 6: Rename variable obfuscated (opsional, best-effort)
    result = cleanupVariableNames(result)

    return result
}

// ── Constant Folding ──────────────────────────────────────────────────────────

function foldConstants(src) {
    let result = src

    // Fold arithmetic: (number op number)
    result = result.replace(/\(\s*(-?\d+(?:\.\d+)?)\s*([+\-*\/])\s*(-?\d+(?:\.\d+)?)\s*\)/g, (_, a, op, b) => {
        const na = parseFloat(a), nb = parseFloat(b)
        let r
        if (op === "+") r = na + nb
        else if (op === "-") r = na - nb
        else if (op === "*") r = na * nb
        else if (op === "/") r = nb !== 0 ? na / nb : null
        if (r !== null && r !== undefined && isFinite(r)) {
            return Number.isInteger(r) ? String(r) : r.toFixed(6)
        }
        return _
    })

    // Fold string concat: ("a" .. "b") → "ab"
    result = result.replace(/"([^"\\]*)"\s*\.\.\s*"([^"\\]*)"/g, (_, a, b) => `"${a}${b}"`)
    result = result.replace(/'([^'\\]*)'\s*\.\.\s*'([^'\\]*)'/g, (_, a, b) => `'${a}${b}'`)

    // Hapus negasi ganda: not not x → x  (terbatas)
    result = result.replace(/not\s+not\s+(\w+)/g, "$1")

    return result
}

// ── Variable Name Cleanup ─────────────────────────────────────────────────────

function cleanupVariableNames(src) {
    // Hapus baris kosong berulang (lebih dari 2)
    let result = src.replace(/\n{3,}/g, "\n\n")

    // Hapus trailing whitespace per baris
    result = result.replace(/[ \t]+$/gm, "")

    return result
}

// ── Entry ──────────────────────────────────────────────────────────────────────

try {
    const src = fs.readFileSync(inp, "utf8")
    const start = performance.now()

    const result = deobfuscate(src)

    fs.writeFileSync(out, result)
    const ms = Math.floor(performance.now() - start)
    console.log(`OK|${ms}`)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}
