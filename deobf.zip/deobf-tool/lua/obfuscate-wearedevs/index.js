const fs = require("fs")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node index.js <input> <output>")
    process.exit(1)
}

;(async () => {
    try {
        const src = fs.readFileSync(inp, "utf8")
        const start = performance.now()

        const res = await fetch("https://wearedevs.net/api/obfuscate", {
            method: "POST",
            headers: { "content-type": "application/json", "User-Agent": "Mozilla/5.0" },
            body: JSON.stringify({ script: src })
        })

        if (!res.ok) {
            console.error(`ERR|HTTP ${res.status}: ${res.statusText}`)
            process.exit(1)
        }

        const json = await res.json()

        if (!json.success) {
            console.error("ERR|" + (json.message || JSON.stringify(json)))
            process.exit(1)
        }

        fs.writeFileSync(out, json.obfuscated)
        process.stdout.write(`OK|${Math.floor(performance.now() - start)}\n`)
    } catch (err) {
        console.error("ERR|" + err.message)
        process.exit(1)
    }
})()
