// deobf-wearedevs/index.js
// Strip WRD anti-tamper wrapper dari output WeAreDevs obfuscator
// Improved: hapus duplikat fungsi, tambah lebih banyak extraction pattern

const fs = require("fs")
const path = require("path")
const { parse, defaultOptions } = require("../../src/parsers/luaparse")
const beautify = require("../../src/parsers/beautifier")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node index.js <input> <output>")
    process.exit(1)
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function is(node, tmpl) {
    if (!node || !tmpl) return false
    for (const k in tmpl) {
        if (tmpl[k] === null) { if (node[k] != null) return false; continue }
        if (typeof tmpl[k] === "object") {
            if (!is(node[k], tmpl[k])) return false
        } else if (node[k] !== tmpl[k]) return false
    }
    return true
}

// ── Strategy 1: if #x == 0 then ... end  (WRD classic wrapper) ────────────────

function scanBodyForZeroLenIf(body) {
    for (const stat of body) {
        if (!stat) continue
        if (stat.type === "IfStatement" && stat.clauses?.length >= 1) {
            const cond = stat.clauses[0].condition
            const isLenCheck = (
                is(cond, { type: "BinaryExpression", operator: "==" }) &&
                (
                    is(cond.left,  { type: "UnaryExpression", operator: "#" }) ||
                    is(cond.right, { type: "UnaryExpression", operator: "#" })
                )
            )
            if (isLenCheck) {
                const payload = (stat.clauses[0].body || []).filter(s =>
                    s && s.type && s.type !== "ReturnStatement"
                )
                if (payload.length) return payload
            }
        }
        const nested = ["ForNumericStatement","WhileStatement","RepeatStatement","DoStatement"]
        if (nested.includes(stat.type)) {
            const found = scanBodyForZeroLenIf(stat.body || [])
            if (found) return found
        }
    }
    return null
}

function findPayloadInIfZeroLen(body) {
    for (const stat of body) {
        if (!stat) continue
        const nested = ["ForNumericStatement","WhileStatement","RepeatStatement","DoStatement"]
        if (nested.includes(stat.type)) {
            const found = scanBodyForZeroLenIf(stat.body || [])
            if (found) return found
        }
        if (stat.type === "IfStatement") {
            for (const clause of stat.clauses) {
                const found = scanBodyForZeroLenIf(clause.body || [])
                if (found) return found
            }
        }
    }
    return null
}

// ── Strategy 2: if r1/v2 then ... end  (WRD condition var wrapper) ────────────

function findPayloadInR1Block(body) {
    for (const stat of body) {
        if (!stat) continue
        if (stat.type === "IfStatement") {
            for (const clause of stat.clauses) {
                const cb = clause.body || []
                const real = cb.filter(s => {
                    if (!s?.type) return false
                    if (s.type === "ReturnStatement") return false
                    return ["CallStatement","LocalStatement","FunctionDeclaration","IfStatement","AssignmentStatement"].includes(s.type)
                })
                if (real.length > 0) return real
            }
        }
    }
    return null
}

// ── Strategy 3: if type(x) == "string" then (alternate WRD format) ────────────

function findPayloadInTypeCheck(body) {
    for (const stat of body) {
        if (!stat || stat.type !== "IfStatement") continue
        for (const clause of stat.clauses) {
            const cond = clause.condition
            // type(x) == "string" / type(x) == "function"
            const isTypeCheck = (
                is(cond, { type: "BinaryExpression", operator: "==" }) &&
                (
                    is(cond.left,  { type: "CallExpression", base: { type: "Identifier", name: "type" } }) ||
                    is(cond.right, { type: "CallExpression", base: { type: "Identifier", name: "type" } })
                )
            )
            if (isTypeCheck) {
                const cb = (clause.body || []).filter(s =>
                    s?.type && s.type !== "ReturnStatement"
                )
                if (cb.length > 2) return cb
            }
        }
    }
    return null
}

// ── Strategy 4: ambil blok do...end terbesar (fallback AST) ───────────────────

function findLargestDoBlock(body) {
    let best = null
    let bestLen = 0
    for (const stat of body) {
        if (!stat) continue
        if (stat.type === "DoStatement") {
            const len = (stat.body || []).length
            if (len > bestLen) { bestLen = len; best = stat.body }
        }
    }
    return bestLen > 3 ? best : null
}

// ── Strategy 5: regex fallback ────────────────────────────────────────────────

function regexFallback(src) {
    const lines = src.split("\n")
    let startLine = -1, endLine = -1

    // Pattern: if r1/v1/v2 then
    for (let i = 0; i < lines.length; i++) {
        if (/^\s*if\s+(r1|v1|v2|_[a-z0-9]+)\s+then/.test(lines[i])) {
            startLine = i + 1; break
        }
    }
    // Cari akhir: return (function ... atau end terakhir
    for (let i = lines.length - 1; i >= 0; i--) {
        if (/return\s*\(function/.test(lines[i]) || /^\s*return\s+\w+\s*$/.test(lines[i])) {
            endLine = i - 1; break
        }
    }

    if (startLine > 0 && endLine > startLine) {
        return lines.slice(startLine, endLine + 1)
            .filter(l => !/^\s*(end;?|until .+)\s*$/.test(l.trim()) || l.trim().length > 5)
            .join("\n").trim()
    }

    // Fallback 2: cari payload di antara dua fungsi besar
    const funcPattern = /^\s*local\s+function\s+\w+/
    const funcLines = []
    for (let i = 0; i < lines.length; i++) {
        if (funcPattern.test(lines[i])) funcLines.push(i)
    }
    if (funcLines.length >= 2) {
        const payloadLines = lines.slice(funcLines[funcLines.length - 1] + 1)
            .filter(l => l.trim() && !/^\s*(end;?)\s*$/.test(l.trim()))
        if (payloadLines.length > 3) return payloadLines.join("\n").trim()
    }

    return null
}

// ── Main stripWRD ──────────────────────────────────────────────────────────────

function stripWRD(src) {
    let ast
    try {
        ast = parse(src, { ...defaultOptions, luaVersion: "5.1", encodingMode: "x-user-defined" })
    } catch (e) {
        throw new Error("parse failed: " + e.message)
    }

    const body = ast.body
    let payloadNodes = null
    let payloadSrc   = null

    const strategies = [
        () => findPayloadInIfZeroLen(body),
        () => findPayloadInR1Block(body),
        () => findPayloadInTypeCheck(body),
        () => findLargestDoBlock(body),
    ]

    for (const strategy of strategies) {
        payloadNodes = strategy()
        if (payloadNodes?.length) {
            try { payloadSrc = beautify({ type: "Chunk", body: payloadNodes }).trim() } catch (_) {}
            if (payloadSrc && payloadSrc.length > 10) break
            payloadSrc = null
        }
    }

    // Regex fallback terakhir
    if (!payloadSrc || payloadSrc.length < 10)
        payloadSrc = regexFallback(src)

    if (!payloadSrc || payloadSrc.length < 10)
        throw new Error("Could not extract payload from WRD output")

    return payloadSrc
}

// ── Entry ──────────────────────────────────────────────────────────────────────

try {
    const src = fs.readFileSync(inp, "utf8")
    const payloadSrc = stripWRD(src)

    fs.writeFileSync(out, payloadSrc + "\n")
    process.stdout.write(`OK|${Math.floor(performance.now())}|${Buffer.byteLength(payloadSrc)}\n`)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}

module.exports = { stripWRD }
