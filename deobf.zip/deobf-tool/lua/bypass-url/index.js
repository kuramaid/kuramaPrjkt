const fs = require("fs")

const url = process.argv[2]
const out = process.argv[3]

if (!url || !out) {
    console.error("Usage: node index.js <url> <output>")
    process.exit(1)
}

// ── Bypass APIs ────────────────────────────────────────────────────────────────
// Dipanggil secara parallel, hasil pertama yang sukses langsung dipakai.
// Kalau semua gagal, coba satu per satu sebagai fallback.

const APIS = [
    {
        name: "bypass-vip",
        fn: async (link) => {
            const res = await fetch(
                `https://api.bypass.vip/premium/bypass?url=${encodeURIComponent(link)}`,
                { headers: { "x-api-key": "e403837d-c640-4017-bb36-581759c79ecf" }, signal: AbortSignal.timeout(25000) }
            )
            if (!res.ok) throw new Error(`HTTP ${res.status}`)
            const j = await res.json()
            if (j.status !== "success") throw new Error(j.message || "bypass failed")
            return j.result
        }
    },
    {
        name: "bypass-lat",
        fn: async (link) => {
            const res = await fetch(
                `https://iwoozie.baby/api/free/bypass?url=${encodeURIComponent(link)}`,
                { signal: AbortSignal.timeout(30000) }
            )
            if (!res.ok) throw new Error(`HTTP ${res.status}`)
            const j = await res.json()
            const bad = [
                "Invalid URL given", "Unsupported URL given",
                "Not Supported by FREE API!", "bypass fail!"
            ]
            if (!j.result || bad.some(b => j.result.startsWith(b)))
                throw new Error(j.result || "bypass failed")
            return j.result
        }
    },
    {
        name: "bypass-guru",
        fn: async (link) => {
            const res = await fetch(
                `https://bypass.guru/api/bypass?url=${encodeURIComponent(link)}`,
                { signal: AbortSignal.timeout(25000) }
            )
            if (!res.ok) throw new Error(`HTTP ${res.status}`)
            const j = await res.json()
            if (!j.result) throw new Error(j.message || "bypass failed")
            return j.result
        }
    },
    {
        name: "bypass-er",
        fn: async (link) => {
            const res = await fetch(
                `https://api.bypass.er.vn/api/bypass?url=${encodeURIComponent(link)}`,
                { signal: AbortSignal.timeout(25000) }
            )
            if (!res.ok) throw new Error(`HTTP ${res.status}`)
            const j = await res.json()
            if (!j.success || !j.result) throw new Error(j.message || "bypass failed")
            return j.result
        }
    }
]

// Jalankan semua API parallel, return hasil pertama yang berhasil
async function raceBypass(link) {
    return new Promise((resolve, reject) => {
        let pending = APIS.length
        const errors = []

        for (const api of APIS) {
            api.fn(link)
                .then(result => {
                    // Validasi result bukan URL API itu sendiri / bukan error
                    if (result && result.startsWith("http") && result !== link) {
                        resolve({ result, source: api.name })
                    } else {
                        throw new Error("invalid result: " + result)
                    }
                })
                .catch(e => {
                    errors.push(`${api.name}: ${e.message}`)
                    pending--
                    if (pending === 0) reject(new Error(errors.join(" | ")))
                })
        }
    })
}

// Fallback: coba satu per satu (sequential) kalau race timeout
async function sequentialBypass(link) {
    const errors = []
    for (const api of APIS) {
        try {
            const result = await api.fn(link)
            if (result && result.startsWith("http") && result !== link)
                return { result, source: api.name }
            errors.push(`${api.name}: invalid result`)
        } catch (e) {
            errors.push(`${api.name}: ${e.message}`)
        }
    }
    throw new Error("All APIs failed:\n" + errors.join("\n"))
}

;(async () => {
    const start = performance.now()
    try {
        let res
        try {
            res = await raceBypass(url)
        } catch (_) {
            // race gagal semua, coba sequential
            res = await sequentialBypass(url)
        }

        fs.writeFileSync(out, res.result)
        const ms = Math.floor(performance.now() - start)
        console.log(`OK|${ms}|${res.source}`)
    } catch (err) {
        console.error("ERR|" + err.message)
        process.exit(1)
    }
})()
