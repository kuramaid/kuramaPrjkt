BESTCFG = {
    "performance": {"hookOp": -2, "runtimelogs": -1, "constants": -2},
    "output":      {"hookOp": 3, "explore_funcs": 1, "spyexeconly": -1, "minifier": 5, "lua": 3, "roblox": -1, "discord": 1},
    "tamper":      {"hookOp": 5, "spyexeconly": 4, "constants": 3, "lua": -1, "roblox": 3}
}

ALIASES = {"speed": "performance", "antitamper": "tamper", "accuracy": "output"}

def applyBestCfg(settings, modes):
    cfg = {}
    for m in modes:
        key = ALIASES.get(m, m)
        diff = BESTCFG.get(key)
        if not diff:
            raise Exception(f"Mode tidak valid: {m}")
        for s, change in diff.items():
            cfg[s] = cfg.get(s, 0) + change
    changed = []
    for k, score in cfg.items():
        if k not in settings:
            continue
        nv = score > 0
        if settings[k]["val"] != nv:
            settings[k]["val"] = nv
            changed.append(f"{'+ ' if nv else '- '}{k}")
    return changed
