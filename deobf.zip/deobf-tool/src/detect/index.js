const fs = require("fs")

const inp = process.argv[2]

if (!inp) {
    console.error("Usage: node index.js <input>")
    process.exit(1)
}

try {
    const src = fs.readFileSync(inp, "utf8")
    let result = "Unknown"

    if (src.includes("=[LPH") || src.includes("!!LPH"))
        result = "Luraph"
    else if (src.match(/\w+\.\w+\(["']#/) || src.match(/\w+\(["']#\w+["']\)/))
        result = "MoonSec V3"
    else if (src.includes("MoonSec") || src.match(/local\s+\w+\s*=\s*\w+;local\s+\w+\s*=\s*\w+\.\w+;/))
        result = "MoonSec (unknown version)"
    else if (src.match(/\d{5,}\+-?\d{5,}/))
        result = "Prometheus"
    else if (src.match(/return \w+\(\w+\(\)\s*,\s*\{\}\s*,\s*\w+\)\(\.\.\.\)/))
        result = "IronBrew 2"
    else if (src.match(/local\s+\w+\s*=\s*\w+\(\w+\(\w+,\s*\w+\)/))
        result = "LuaObfuscator (string enc)"
    else if (src.includes("WeAreDevs") || src.match(/if\s+(r1|v1|v2)\s+then/) || src.match(/if\s+#\w+\s*==\s*0\s+then/))
        result = "WeAreDevs"

    console.log("OK|" + result)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}
