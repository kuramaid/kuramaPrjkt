// semantic-rename.js
// Renames junk register variables (r1, v1, r50...) to meaningful names
// by analysing their assigned values and usage context.

const walk = (node, fn) => {
    if (!node || typeof node !== "object") return
    fn(node)
    for (const key of Object.keys(node)) {
        const val = node[key]
        if (Array.isArray(val)) val.forEach(c => walk(c, fn))
        else if (val && typeof val === "object" && val.type) walk(val, fn)
    }
}

const IS_JUNK = /^[rv]\d+$|^[A-Z]{1,3}V$|^[a-zA-Z]{1,2}$/ // r1, v10, ZV, XV, kV etc.

// ── helpers ────────────────────────────────────────────────────────────────────

function getCallName(node) {
    // game:GetService("Players") → "Players"
    if (node?.type === "CallExpression") {
        const args = node.arguments
        if (args?.length >= 1 && args[0]?.type === "StringLiteral")
            return args[0].value
    }
    return null
}

function getMemberBase(node) {
    // x.FindFirstChild(x, "Foo") → "Foo"
    if (node?.type === "CallExpression") {
        const args = node.arguments
        if (args?.length >= 2 && args[1]?.type === "StringLiteral")
            return args[1].value
    }
    return null
}

function baseName(node) {
    if (!node) return null
    switch (node.type) {
        case "StringLiteral":
            // e.g. "\xcet..." junk strings → skip
            if (/[\x00-\x1f\x80-\xff]/.test(node.value)) return null
            // "Players" → "players" etc
            return node.value.replace(/[^a-zA-Z0-9_]/g, "_").replace(/^[0-9]/, "_$&")
        case "Identifier":
            return IS_JUNK.test(node.name) ? null : node.name
        case "MemberExpression":
            return node.identifier?.name || null
        case "CallExpression": {
            // game:GetService("X") → "X"
            const svc = getCallName(node)
            if (svc) return svc
            // x.FindFirstChild(x, "Y") → "Y"
            const fc = getMemberBase(node)
            if (fc) return fc
            // require(mod) → "module"
            if (node.base?.name === "require") return "module"
            // Instance.new("X") → firstword of X lowercased
            if (
                node.base?.type === "MemberExpression" &&
                node.base?.base?.name === "Instance" &&
                node.base?.identifier?.name === "new"
            ) {
                const t = node.arguments?.[0]?.value
                if (t) return t.replace(/[A-Z]/g, c => "_" + c.toLowerCase()).replace(/^_/, "")
            }
            // pcall → "ok" / "result"
            if (node.base?.name === "pcall") return "result"
            return null
        }
        case "IndexExpression":
            return node.index?.value != null ? null : node.base?.name || null
        case "TableConstructorExpression":
            return "table"
        case "FunctionDeclaration":
            return "fn"
        case "BinaryExpression":
        case "UnaryExpression":
            return null
        default:
            return null
    }
}

// Known service/global patterns → fixed name
const KNOWN = {
    // services
    Players: "Players",
    RunService: "RunService",
    StarterGui: "StarterGui",
    UserInputService: "UserInputService",
    ReplicatedStorage: "ReplicatedStorage",
    TweenService: "TweenService",
    HttpService: "HttpService",
    Workspace: "Workspace",
    // common globals
    math: "math",
    string: "string",
    table: "table",
    task: "task",
    game: "game",
    // common functions
    pcall: "pcall",
    unpack: "unpack",
    select: "select",
    getfenv: "getfenv",
    setmetatable: "mt",
    tostring: "tostring",
    tonumber: "tonumber",
    pairs: "pairs",
    ipairs: "ipairs",
    next: "next",
    print: "print",
    error: "error",
    require: "require",
}

// ── Instance.new known type → camelCase name ───────────────────────────────────
const INSTANCE_NAMES = {
    ScreenGui:       "screenGui",
    Frame:           "frame",
    TextLabel:       "label",
    TextButton:      "button",
    TextBox:         "textBox",
    ImageLabel:      "imageLabel",
    ImageButton:     "imageButton",
    ScrollingFrame:  "scrollFrame",
    UICorner:        "corner",
    UIPadding:       "padding",
    UIListLayout:    "listLayout",
    UIGridLayout:    "gridLayout",
    UIStroke:        "stroke",
    RemoteEvent:     "remote",
    RemoteFunction:  "remoteFunc",
    ModuleScript:    "module",
    LocalScript:     "script",
    BindableEvent:   "bindable",
    Part:            "part",
    Model:           "model",
    Folder:          "folder",
    Configuration:   "config",
    StringValue:     "strVal",
    NumberValue:     "numVal",
    BoolValue:       "boolVal",
}

// ── Gather all assignments in a flat list ─────────────────────────────────────
function collectAssignments(body) {
    const result = [] // { varName, initNode, stat }
    walk({ body }, node => {
        if (node.type === "LocalStatement" || node.type === "AssignmentStatement") {
            const vars = node.variables ?? []
            const inits = node.init ?? []
            for (let i = 0; i < vars.length; i++) {
                if (vars[i]?.type === "Identifier")
                    result.push({ varName: vars[i].name, initNode: inits[i] ?? null, varNode: vars[i] })
            }
        }
        if (node.type === "FunctionDeclaration" && node.identifier?.type === "Identifier")
            result.push({ varName: node.identifier.name, initNode: node, varNode: node.identifier })
    })
    return result
}

// ── Infer a good name from an init expression ──────────────────────────────────
function inferName(initNode, assignments) {
    if (!initNode) return null

    // Instance.new("X")
    if (
        initNode.type === "CallExpression" &&
        initNode.base?.type === "MemberExpression" &&
        initNode.base?.base?.name === "Instance" &&
        initNode.base?.identifier?.name === "new"
    ) {
        const t = initNode.arguments?.[0]?.value
        if (t && INSTANCE_NAMES[t]) return INSTANCE_NAMES[t]
        if (t) return t.charAt(0).toLowerCase() + t.slice(1)
    }

    // game:GetService("X")
    if (
        initNode.type === "CallExpression" &&
        (initNode.base?.identifier?.name === "GetService" ||
         initNode.base?.name === "GetService")
    ) {
        const svc = initNode.arguments?.find(a => a.type === "StringLiteral")?.value
        if (svc && KNOWN[svc]) return KNOWN[svc]
        if (svc) return svc.charAt(0).toLowerCase() + svc.slice(1)
    }

    // x.FindFirstChild(x, "Name") or x:FindFirstChild("Name")
    if (
        initNode.type === "CallExpression" &&
        (initNode.base?.identifier?.name === "FindFirstChild" ||
         initNode.base?.identifier?.name === "WaitForChild" ||
         initNode.base?.identifier?.name === "FindFirstChildOfClass")
    ) {
        // args: (self, "Name") or just ("Name")
        const nameArg = initNode.arguments?.find(a => a.type === "StringLiteral")
        if (nameArg) {
            const n = nameArg.value
            return n.charAt(0).toLowerCase() + n.slice(1).replace(/[^a-zA-Z0-9_]/g, "")
        }
    }

    // require(mod)
    if (initNode.type === "CallExpression" && initNode.base?.name === "require") {
        const mod = initNode.arguments?.[0]
        if (mod?.type === "Identifier" && !IS_JUNK.test(mod.name)) return mod.name + "Module"
        // try to look up what the arg was assigned
        if (mod?.type === "Identifier") {
            const prev = assignments.find(a => a.varName === mod.name)
            const n = prev ? inferName(prev.initNode, assignments) : null
            if (n) return n + "Module"
        }
        return "module"
    }

    // setmetatable({}, {...}) → keep as "mt" + context
    if (initNode.type === "CallExpression" && initNode.base?.name === "setmetatable")
        return "mt"

    // Color3.fromRGB → color  (skip, too generic, handled by usage)
    if (
        initNode.type === "CallExpression" &&
        initNode.base?.base?.name === "Color3"
    ) return "color"

    // UDim2.new → udim
    if (
        initNode.type === "CallExpression" &&
        initNode.base?.base?.name === "UDim2"
    ) return "udim"

    // UDim.new → udim
    if (
        initNode.type === "CallExpression" &&
        initNode.base?.base?.name === "UDim"
    ) return "udimVal"

    // Enum.X.Y  (e.g. assigned to a local)
    if (initNode.type === "MemberExpression" && initNode.base?.base?.name === "Enum")
        return "enum" + (initNode.identifier?.name || "")

    // FunctionDeclaration (local function)
    if (initNode.type === "FunctionDeclaration") return null // keep body name

    // Identifier pointing to a known name
    if (initNode.type === "Identifier") {
        if (KNOWN[initNode.name]) return KNOWN[initNode.name]
        if (!IS_JUNK.test(initNode.name)) return initNode.name
    }

    // string literal short & clean
    if (initNode.type === "StringLiteral") {
        const v = initNode.value
        if (v.length <= 32 && /^[\x20-\x7e]+$/.test(v)) {
            const cleaned = v.replace(/[^a-zA-Z0-9_]/g, "_").replace(/^[0-9]/, "_$&")
            if (cleaned.length >= 1) return cleaned.toLowerCase()
        }
    }

    // Players.LocalPlayer
    if (
        initNode.type === "MemberExpression" &&
        initNode.identifier?.name === "LocalPlayer"
    ) return "localPlayer"

    // x[2] where x is a pcall result table
    if (
        initNode.type === "IndexExpression" &&
        initNode.index?.type === "NumericLiteral" &&
        initNode.index?.value === 2
    ) return "result"

    return null
}

// ── Deduplicate names ─────────────────────────────────────────────────────────
function makeUnique(name, used) {
    if (!used.has(name)) { used.add(name); return name }
    let i = 2
    while (used.has(name + i)) i++
    used.add(name + i)
    return name + i
}

// ── Main export ───────────────────────────────────────────────────────────────
function semanticRename(body) {
    const assignments = collectAssignments(body)
    const renameMap = new Map()   // oldName → newName
    const used      = new Set([
        // reserve Lua builtins / globals
        "print","error","pcall","xpcall","require","select","unpack","type",
        "tostring","tonumber","pairs","ipairs","next","rawget","rawset",
        "setmetatable","getmetatable","assert","string","table","math",
        "io","os","coroutine","debug","package","bit","utf8",
        "game","workspace","script","Enum","Instance","UDim","UDim2",
        "Vector2","Vector3","Color3","CFrame","TweenInfo","RaycastParams",
        "task","wait","spawn","delay","tick","time",
        "Players","RunService","StarterGui","UserInputService","ReplicatedStorage",
        "Env","_G","_ENV",
    ])

    // Pass 1: figure out a good name for each junk variable
    for (const { varName, initNode } of assignments) {
        if (!IS_JUNK.test(varName)) continue          // already has a good name
        if (renameMap.has(varName)) continue           // already renamed

        let name = inferName(initNode, assignments)
        if (!name) name = varName                     // fallback: keep original

        // clean up
        name = name.replace(/[^a-zA-Z0-9_]/g, "").replace(/^[0-9]/, "_$&") || varName

        if (IS_JUNK.test(name) || name === varName) {
            // still junk — keep original, don't rename
            renameMap.set(varName, varName)
            used.add(varName)
        } else {
            const unique = makeUnique(name, used)
            renameMap.set(varName, unique)
        }
    }

    // Pass 2: apply renaming everywhere in the AST
    walk({ body }, node => {
        if (node.type === "Identifier" && renameMap.has(node.name)) {
            node.name = renameMap.get(node.name)
        }
    })
}

module.exports = semanticRename
