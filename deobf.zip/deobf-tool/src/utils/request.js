// Roblox-spoofed HTTP GET — drop-in replacement for request-promise
const { randomBytes } = require("crypto")

const rndHex = (n) => randomBytes(n).toString("hex")
const rndDec = (n) => {
    let r = ""
    for (let i = 0; i < n; i++) r += Math.floor(Math.random() * 10)
    return r
}
const rndAlpha = (n) => {
    const c = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    let r = ""
    for (let i = 0; i < n; i++) r += c[Math.floor(Math.random() * c.length)]
    return r
}

const ROBLOX_UA = [
    "Roblox/WinInet",
    "RobloxApp/0.610.0.6100514 (GlobalDist; RobloxDirectDownload)",
    "Roblox/Darwin"
]

const spoofHeaders = (url) => {
    // if the url is a roblox.com subdomain, don't spoof (their own CDN rejects weird headers)
    if (/https?:\/\/\w+\.roblox\.com/.test(url))
        return { "User-Agent": ROBLOX_UA[0] }
    return {
        "User-Agent":        ROBLOX_UA[Math.floor(Math.random() * ROBLOX_UA.length)],
        "traceparent":       `00-${rndHex(16)}${rndHex(16)}-${rndHex(8)}-00`,
        "Roblox-Id":         rndDec(16),
        "Krnl-Fingerprint":  rndAlpha(16),
        "Accept":            "*/*",
        "Accept-Language":   "en-US,en;q=0.9"
    }
}

/**
 * @param {string} url
 * @returns {Promise<[boolean, string]>}
 */
const request = async (url) => {
    try {
        const res = await fetch(url, {
            method: "GET",
            headers: spoofHeaders(url)
        })
        if (!res.ok)
            return [false, `> Unable to fetch url, message: ${res.status}: ${res.statusText}`]
        const content = await res.text()
        return [true, content]
    } catch (err) {
        return [false, `> Unable to fetch url, message: ${err.message}`]
    }
}

// standalone mode: node request.js <url>
;(async () => {
    const arg = process.argv[2]
    if (!arg) return
    const [ok, content] = await request(arg)
    if (!ok) { console.error(content); process.exit(1) }
    console.log(content)
})()

module.exports = request
