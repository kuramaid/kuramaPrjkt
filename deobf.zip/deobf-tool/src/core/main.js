// main.js — Prometheus deobfuscator entry point
// argv[2] = input file
// argv[3] = output file
// argv[4] = "true" → also save formatted.lua (debug)
// argv[5] = "true" → skip inline + localify

// Fix: dynamic import of luau-web inside an async IIFE so Node CJS loader
// doesn't choke on top-level await / import() parse order.
const fs = require("fs").promises

const beautify        = require("../parsers/beautifier")
const { parse, defaultOptions } = require("../parsers/luaparse")
const simpleAst       = require("../utils/simple-ast")
const { inline, setInlineOptions } = require("../deobfuscators/inlinev4")
const localify        = require("../utils/localify")
const semanticRename  = require("../utils/semantic-rename")
const { is, search, searchIs } = require("../utils/helper")
const indexCleaner    = require("../utils/indexCleaner")
const indexFixer      = require("../utils/indexFixer")
const query           = require("../utils/query")

const runStep = (p, ...args) => {
    const deobfPath = "../deobfuscators/" + p
    const utilPath  = "../utils/" + p
    let mod
    try        { mod = require(deobfPath) }
    catch (_)  { mod = require(utilPath)  }
    return mod(...args)
}

defaultOptions.comments = false

async function deobfuscate(inputPath, outFile, saveFormatted, skipInline) {
    // dynamic import — must be inside async fn, works in CJS on Node 18+
    const { LuauState } = await import("luau-web")

    const Options = { fork: null, iterStats: [] }

    const src     = (await fs.readFile(inputPath)).toString()
    const content = beautify(src)
    const start   = performance.now()

    if (/getgenv\(\)\[.+\] = function\(/.test(content))
        Options.fork = "25ms"

    let output = []

    let fileAst
    try {
        fileAst = parse(content)
    } catch (err) {
        throw new Error("Unable to parse AST: " + err.message)
    }

    const State = await LuauState.createAsync()

    // normalize CompoundAssignment → regular AssignmentStatement
    query(fileAst, "CompoundAssignmentStatement").forEach((stat) => {
        const { variable, op, value } = stat
        Object.assign(stat, {
            type:      "AssignmentStatement",
            variables: [variable],
            init: [{
                type:     "BinaryExpression",
                operator: op,
                left:     variable,
                right:    value
            }]
        })
    })

    const MainFunctions = searchIs(fileAst, {
        type:      "CallExpression",
        base:      { type: "FunctionDeclaration" },
        arguments: []
    })

    const VarargTable = simpleAst.varargTable()

    let MainFunction, EnvIdx

    for (const f of MainFunctions) {
        if (f.arguments.find((a) => is(a, VarargTable))) {
            MainFunction = f
            for (let i = 0; i < f.arguments.length; i++) {
                if (is(f.arguments[i], {
                    type:     "LogicalExpression",
                    operator: "or",
                    left:     { left: { name: "getfenv" } }
                })) { EnvIdx = i; break }
            }
            break
        }
    }

    if (!MainFunction) {
        await fs.writeFile("formatted.lua", beautify(fileAst))
        throw new Error("Unable to locate MainFunction")
    }

    const Env = MainFunction.base.parameters[EnvIdx]
    if (!Env) throw new Error("Unable to find the Env parameter")

    let WhileStat, Pc, ReturnVar, Upvalues, FunctionParams, Unpack,
        Select    = { type: "Identifier", name: "select" },
        StartOpc,
        Dispatchers = {}

    ;(() => {
        let counter = 0
        for (const param of MainFunction.arguments) {
            if (is(param, { type: "LogicalExpression", operator: "or", left: { name: "unpack" } }))
                Unpack = MainFunction.base.parameters[counter]
            else if (is(param, { name: "select" }))
                Select = MainFunction.base.parameters[counter]
            counter++
        }
        const body = MainFunction.base.body
        const last = body[body.length - 1]
        if (is(last, {
            type: "ReturnStatement",
            arguments: [{ base: { type: "CallExpression", base: { type: "Identifier" }, arguments: [{ type: "NumericLiteral" }, { type: "TableConstructorExpression" }] } }]
        }))
            StartOpc = last.arguments[0].base.arguments[0].value
    })()

    for (const { parameters, body } of search(MainFunction, "FunctionDeclaration")) {
        const Param      = parameters[0]
        const LastStat   = body[body.length - 1]
        const LastStat_2 = body[body.length - 2]
        if (
            is(LastStat,   { type: "ReturnStatement",    arguments: [{ type: "CallExpression", base: Unpack }] }) &&
            is(LastStat_2, { type: "AssignmentStatement", init: [{ type: "UnaryExpression", operator: "#" }], variables: [Param] })
        ) {
            ReturnVar = LastStat.arguments[0].arguments[0]
            Pc        = Param
            Upvalues  = parameters[2]
            FunctionParams = parameters[1]
            for (const stat of body)
                if (stat.type === "WhileStatement") { WhileStat = stat; break }
        }
    }

    const { RegTable } = runStep("functions", MainFunction.base, Dispatchers)

    output = await runStep("constarray", fileAst, output, State, Options)

    if (saveFormatted)
        await fs.writeFile("formatted.lua", beautify(fileAst))

    ;(() => {
        const IfStat = search(WhileStat, "IfStatement")[0] || WhileStat
        const data   = runStep("uncff", IfStat, StartOpc, {
            pc: Pc, dispatchers: Dispatchers, returnVar: ReturnVar,
            env: Env, upv: Upvalues, params: FunctionParams, reg: RegTable
        })
        for (const i of data) output.push(i)
    })()

    runStep("repeatfix", output)

    const dontLocalify = new Set()

    if (!skipInline) {
        setInlineOptions({ simplifyCalls: true, RegTable, Unpack: Unpack?.name })
        try { inline(output) }      catch (err) { console.error("UNABLE TO INLINE", err) }
        try { indexFixer(output) }  catch (err) { console.error("failed to fix indexes", err) }
        runStep("cleaner", output, {
            Env, FunctionParams, RegTable,
            Parameters: { Select, Unpack }
        }, dontLocalify)
    }

    await new Promise(async (res) => {
        try {
            const s = performance.now()
            output = await runStep("decrypt", output, Options.iterStats, {
                upvalues: Upvalues, regtable: RegTable
            }, State)
            console.log("Decrypted strings in", Math.floor(performance.now() - s), "ms!")
        } catch (err) {
            if (err.message === "Encrypt strings is off")
                console.log("Encrypt strings is off")
            else
                console.error("Errored while decrypting strings:", err)
        }
        res(1)
    })

    indexCleaner(output, Env)

    if (!skipInline)
        localify(output, dontLocalify)

    // semantic rename: turn r1/v8/ZV etc into meaningful names
    try { semanticRename(output) } catch (err) { console.error("semantic-rename failed:", err.message) }

    try { indexFixer(output) } catch (err) { console.error("failed to fix final indexes", err) }

    console.log("Done in", (performance.now() - start).toFixed(2), "ms.")

    await fs.writeFile(outFile, beautify(
        [
            { type: "LocalStatement", variables: [simpleAst.ident("Env")], init: [{ type: "CallExpression", base: simpleAst.ident("getfenv"), arguments: [] }] },
            { type: "LocalStatement", variables: [RegTable], init: [simpleAst.emptyTable()] }
        ].concat(output),
        { solveMath: false }
    ))
}

// ── entry ─────────────────────────────────────────────────────────────────────
const inputPath     = process.argv[2]
const outFile       = process.argv[3] || "out.lua"
const saveFormatted = false
const skipInline    = false

if (!inputPath) {
    console.error("Usage: node main.js <input> <output> [saveFormatted] [skipInline]")
    process.exit(1)
}

deobfuscate(inputPath, outFile, saveFormatted, skipInline).catch((err) => {
    console.error("Deobfuscation failed:", err.message || err)
    process.exit(1)
})
