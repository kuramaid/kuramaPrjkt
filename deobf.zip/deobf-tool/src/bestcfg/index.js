const BESTCFG = {
    performance: { hookOp: -2, runtimelogs: -1, constants: -2 },
    output:      { hookOp: 3, explore_funcs: 1, spyexeconly: -1, minifier: 5, lua: 3, roblox: -1, discord: 1 },
    tamper:      { hookOp: 5, spyexeconly: 4, constants: 3, lua: -1, roblox: 3 }
}

const ALIASES = { speed: "performance", antitamper: "tamper", accuracy: "output" }

function applyBestCfg(settings, modes) {
    const cfg = {}
    for (const m of modes) {
        const key = ALIASES[m] || m
        const diff = BESTCFG[key]
        if (!diff) throw new Error(`Mode tidak valid: ${m}`)
        for (const s in diff) {
            cfg[s] = (cfg[s] || 0) + diff[s]
        }
    }
    const changed = []
    for (const k in cfg) {
        if (!(k in settings)) continue
        const nv = cfg[k] > 0
        if (settings[k].val !== nv) {
            settings[k].val = nv
            changed.push(`${nv ? "+ " : "- "}${k}`)
        }
    }
    return changed
}

module.exports = { applyBestCfg, ALIASES, BESTCFG }
