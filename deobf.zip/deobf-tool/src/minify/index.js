const fs = require("fs")
const minify = require("../../src/parsers/minify")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node index.js <input> <output>")
    process.exit(1)
}

try {
    const src = fs.readFileSync(inp, "utf8")
    const result = minify(src)
    fs.writeFileSync(out, result)
    const orig = Buffer.byteLength(src, "utf8")
    const done = Buffer.byteLength(result, "utf8")
    console.log(`OK|${orig}|${done}`)
} catch (err) {
    console.error("ERR|" + err.message)
    process.exit(1)
}
