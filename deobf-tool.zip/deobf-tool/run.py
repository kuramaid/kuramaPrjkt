#!/usr/bin/env python3
import os
import sys
import subprocess
import shutil
import json
import time
import tempfile
from pathlib import Path

BASE = Path(__file__).parent.resolve()
CORE = BASE / "src" / "core"
NODE_MODULES = BASE / "node_modules"

R = "\033[91m"; G = "\033[92m"; Y = "\033[93m"
B = "\033[94m"; C = "\033[96m"; W = "\033[97m"
DIM = "\033[2m"; BOLD = "\033[1m"; RST = "\033[0m"

SETTINGS = {
    "hookOp":        {"val": True,  "desc": "Hook operations (repeat/while/if/comparisons)"},
    "explore_funcs": {"val": True,  "desc": "Log stuff inside functions"},
    "spyexeconly":   {"val": False, "desc": "Only spy executor variables"},
    "minifier":      {"val": True,  "desc": "Inline outputs (easier to read)"},
    "constants":     {"val": False, "desc": "Collect all detected strings"},
    "lua":           {"val": False, "desc": "Allow require() with any string"},
    "roblox":        {"val": False, "desc": "Error on wrong script behavior"},
    "runtimelogs":   {"val": False, "desc": "Save scripts during processing"},
    "comments":      {"val": False, "desc": "Add comments to output code"},
    "discord":       {"val": True,  "desc": "Log as many things as possible"},
}

BLACKLISTED_SITES = [
    "pornhub", "xvideos", "xnxx", "onlyfans", "brazzers",
    "youporn", "redtube", "tube8", "spankbang"
]

BESTCFG_VALUES = {
    "performance": {"hookOp": -2, "runtimelogs": -1, "constants": -2},
    "output":      {"hookOp": 3, "explore_funcs": 1, "spyexeconly": -1, "minifier": 5, "lua": 3, "roblox": -1, "discord": 1},
    "tamper":      {"hookOp": 5, "spyexeconly": 4, "constants": 3, "lua": -1, "roblox": 3},
}
BESTCFG_ALIASES = {"speed": "performance", "antitamper": "tamper", "accuracy": "output"}

def clr(): os.system("clear")
def pr(t=""): print(t)
def ok(m): print(f"  {G}✓{RST} {m}")
def err(m): print(f"  {R}✗{RST} {m}")
def info(m): print(f"  {Y}→{RST} {m}")
def inp(m): return input(f"  {C}›{RST} {m}").strip()
def sep(): print(f"  {DIM}{'─'*50}{RST}")

def title(sub=""):
    clr()
    print(f"{B}{BOLD}")
    print("  ██████╗ ███████╗ ██████╗ ██████╗ ███████╗")
    print("  ██╔══██╗██╔════╝██╔═══██╗██╔══██╗██╔════╝")
    print("  ██║  ██║█████╗  ██║   ██║██████╔╝█████╗  ")
    print("  ██║  ██║██╔══╝  ██║   ██║██╔══██╗██╔══╝  ")
    print("  ██████╔╝███████╗╚██████╔╝██████╔╝██║     ")
    print("  ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ")
    print(f"{RST}{C}          Lua Deobfuscator | KuramaMods{RST}")
    sep()
    if sub:
        print(f"\n  {BOLD}{W}[ {sub} ]{RST}\n")

def node_run(script, args=[], capture=True):
    cmd = ["node", str(CORE / script)] + [str(a) for a in args]
    r = subprocess.run(cmd, cwd=str(BASE), capture_output=capture, text=True)
    return r.returncode, r.stdout.strip() if capture else "", r.stderr.strip() if capture else ""

def check_node():
    if not shutil.which("node"):
        err("Node.js tidak ditemukan!")
        pr(); info("Install: apt install nodejs  atau  pkg install nodejs")
        input(f"\n  {Y}Tekan Enter keluar...{RST}"); sys.exit(1)

def ensure_deps():
    title()
    info("Memeriksa dependensi...")
    pr()
    check_node()
    try:
        r = subprocess.run(["node", "--version"], capture_output=True, text=True)
        ok(f"Node.js {r.stdout.strip()}")
    except: pass

    if not NODE_MODULES.exists():
        pr(); info("Menginstall npm dependencies...")
        pr(); sep()
        subprocess.run(["npm", "install"], cwd=str(BASE))
        sep(); pr()
        if NODE_MODULES.exists(): ok("Dependencies terinstall!")
        else: err("Gagal install! Jalankan: npm install"); input(f"\n  {Y}Enter...{RST}"); sys.exit(1)
    else:
        ok("node_modules OK")

    pr(); ok("Siap!"); time.sleep(0.8)

def fix_output_path(inp_path, out_str, suffix="_out", ext=".lua"):
    if not out_str:
        return Path(inp_path).parent / (Path(inp_path).stem + suffix + ext)
    p = Path(out_str)
    if p.is_dir() or str(out_str).endswith(("/", "\\")):
        return p / (Path(inp_path).stem + suffix + ext)
    if not p.suffix:
        return p.parent / (p.name + ext)
    return p

def validate_lua(path):
    p = Path(path)
    if not p.exists(): return False, f"File tidak ditemukan: {path}"
    if p.stat().st_size == 0: return False, "File kosong"
    return True, ""

def wait(): input(f"\n  {Y}Tekan Enter untuk kembali...{RST}")

# ─────────────────────────────────────────────
# [1] DEOBFUSCATE (Prometheus)
# ─────────────────────────────────────────────
def menu_deobf():
    title("DEOBFUSCATE")
    info("Deobfuscate script Prometheus/IronBrew2 ke Lua readable")
    pr()

    src = inp("Input file (.lua): ")
    if not src: return
    valid, msg = validate_lua(src)
    if not valid: err(msg); wait(); return

    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_deobf.lua]: ")
    out_p = fix_output_path(src_p, out_s, "_deobf").resolve()

    pr()
    print(f"  {DIM}[1]{RST} Default")
    print(f"  {DIM}[2]{RST} Simpan formatted.lua (debug)")
    print(f"  {DIM}[3]{RST} Skip inlining & localify")
    pr()
    mode = inp("Mode [1/2/3, default=1]: ") or "1"

    args = [str(CORE / "main.js"), str(src_p), str(out_p)]
    if mode == "2": args += ["", "true"]
    elif mode == "3": args += ["", "", "true"]

    pr(); info(f"Processing: {src_p.name}"); sep()
    t = time.time()
    code = subprocess.run(["node"] + args[1:], cwd=str(BASE)).returncode
    elapsed = time.time() - t
    sep(); pr()

    if code == 0:
        ok(f"Selesai dalam {elapsed:.2f}s")
        ok(f"Output: {out_p}")
    else:
        err(f"Gagal (exit code {code})")
    wait()

# ─────────────────────────────────────────────
# [2] BEAUTIFY (alias: bf, coolify)
# ─────────────────────────────────────────────
def menu_beautify():
    title("BEAUTIFY LUA  [bf / coolify]")
    info("Format/beautify kode Lua dengan lua_beautifier")
    pr()

    src = inp("Input file (.lua/.luau): ")
    if not src: return
    valid, msg = validate_lua(src)
    if not valid: err(msg); wait(); return

    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_formatted.lua]: ")
    out_p = fix_output_path(src_p, out_s, "_formatted").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)

    pr(); info("Beautifying..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("beautify.js", [src_p, out_p])
    elapsed = time.time() - t
    sep(); pr()

    if code == 0 and stdout.startswith("OK|"):
        parts = stdout.split("|")
        orig, done = int(parts[1]), int(parts[2])
        ok(f"Selesai dalam {elapsed:.2f}s")
        ok(f"Ukuran: {orig} → {done} bytes")
        ok(f"Output: {out_p}")
    else:
        err("Gagal beautify")
        if stderr: print(f"  {DIM}{stderr}{RST}")
    wait()

# ─────────────────────────────────────────────
# [3] MINIFY
# ─────────────────────────────────────────────
def menu_minify():
    title("MINIFY LUA")
    info("Minify/compress kode Lua")
    pr()

    src = inp("Input file (.lua): ")
    if not src: return
    valid, msg = validate_lua(src)
    if not valid: err(msg); wait(); return

    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_min.lua]: ")
    out_p = fix_output_path(src_p, out_s, "_min").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)

    pr(); info("Minifying..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("minify.js", [src_p, out_p])
    elapsed = time.time() - t
    sep(); pr()

    if code == 0 and stdout.startswith("OK|"):
        parts = stdout.split("|")
        orig, done = int(parts[1]), int(parts[2])
        pct = (1 - done / orig) * 100 if orig else 0
        ok(f"Selesai dalam {elapsed:.2f}s")
        ok(f"Ukuran: {orig} → {done} bytes ({pct:.1f}% lebih kecil)")
        ok(f"Output: {out_p}")
    else:
        err("Gagal minify")
        if stderr: print(f"  {DIM}{stderr}{RST}")
    wait()

# ─────────────────────────────────────────────
# [4] LUAOBF DEOBF (alias: noluaobf)
# ─────────────────────────────────────────────
def menu_luaobf():
    title("LUAOBFUSCATOR DEOBF  [noluaobf]")
    info("Deobfuscate file luaobfuscator.com (string encryption)")
    pr()

    src = inp("Input file (.lua): ")
    if not src: return
    valid, msg = validate_lua(src)
    if not valid: err(msg); wait(); return

    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_deobf.lua]: ")
    out_p = fix_output_path(src_p, out_s, "_deobf").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)

    pr(); info("Deobfuscating luaobf..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("luaobf.js", [src_p, out_p])
    elapsed = time.time() - t
    sep(); pr()

    if code == 0 and stdout.startswith("OK|"):
        ms = stdout.split("|")[1]
        ok(f"Selesai dalam {ms}ms")
        ok(f"Output: {out_p}")
    else:
        err("Gagal deobfuscate")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
        pr()
        info("Pastikan file dari luaobfuscator.com dengan string encryption only.")
    wait()

# ─────────────────────────────────────────────
# [5] WEAREDEVS OBFUSCATE (alias: wearedevs)
# ─────────────────────────────────────────────
def menu_wrd():
    title("WEAREDEVS OBFUSCATE  [wearedevs]")
    info("Obfuscate script menggunakan WeAreDevs obfuscator API")
    pr()

    src = inp("Input file (.lua): ")
    if not src: return
    valid, msg = validate_lua(src)
    if not valid: err(msg); wait(); return

    src_p = Path(src).resolve()
    out_s = inp(f"Output file [{src_p.stem}_obf.lua]: ")
    out_p = fix_output_path(src_p, out_s, "_obf").resolve()
    out_p.parent.mkdir(parents=True, exist_ok=True)

    pr(); info("Mengirim ke WeAreDevs API..."); sep()
    t = time.time()
    code, stdout, stderr = node_run("wearedevs.js", [src_p, out_p])
    elapsed = time.time() - t
    sep(); pr()

    if code == 0 and stdout.startswith("OK|"):
        ms = stdout.split("|")[1]
        ok(f"Selesai dalam {ms}ms")
        ok(f"Output: {out_p}")
    else:
        err("Gagal obfuscate via WeAreDevs")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
    wait()

# ─────────────────────────────────────────────
# [6] HTTP GET (alias: http, httpget, wget)
# ─────────────────────────────────────────────
def menu_httpget():
    title("HTTP GET  [http / httpget / wget]")
    info("Kirim GET request ke URL dan simpan hasilnya")
    pr()

    url = inp("URL (https://...): ")
    if not url:
        return
    if not url.startswith("http"):
        err("URL harus dimulai dengan http/https"); wait(); return

    for site in BLACKLISTED_SITES:
        if site in url.lower():
            err("URL diblacklist"); wait(); return

    out_s = inp("Output file [result.txt]: ")
    if not out_s:
        out_s = "result.txt"
    out_p = Path(out_s).resolve()
    if out_p.is_dir():
        out_p = out_p / "result.txt"
    out_p.parent.mkdir(parents=True, exist_ok=True)

    pr(); info(f"Fetching: {url}"); sep()
    t = time.time()
    code, stdout, stderr = node_run("httpget.js", [url, out_p])
    elapsed = time.time() - t
    sep(); pr()

    if code == 0 and stdout.startswith("OK|"):
        parts = stdout.split("|")
        ms, size = parts[1], int(parts[2])
        ok(f"Selesai dalam {ms}ms")
        ok(f"Ukuran: {size} bytes")
        ok(f"Output: {out_p}")
    else:
        err("Gagal fetch URL")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
    wait()

# ─────────────────────────────────────────────
# [7] BYPASS LINK (alias: bp)
# ─────────────────────────────────────────────
def menu_bypass():
    title("BYPASS LINK  [bp]")
    info("Bypass advertisement/shortlink menggunakan bypass.vip")
    pr()

    url = inp("Link (https://...): ")
    if not url:
        return
    if not url.startswith("http"):
        err("Link harus dimulai dengan http/https"); wait(); return

    out_s = inp("Output file [bypassed.txt]: ")
    if not out_s:
        out_s = "bypassed.txt"
    out_p = Path(out_s).resolve()
    if out_p.is_dir():
        out_p = out_p / "bypassed.txt"
    out_p.parent.mkdir(parents=True, exist_ok=True)

    pr(); info(f"Bypassing: {url}"); sep()
    t = time.time()
    code, stdout, stderr = node_run("bypass.js", [url, out_p])
    elapsed = time.time() - t
    sep(); pr()

    if code == 0 and stdout.startswith("OK|"):
        ms = stdout.split("|")[1]
        ok(f"Berhasil bypass dalam {ms}ms!")
        ok(f"Output: {out_p}")
        pr()
        try:
            result = out_p.read_text()
            info(f"Result: {result[:200]}")
        except: pass
    else:
        err("Gagal bypass")
        if stderr: print(f"  {DIM}{stderr.replace('ERR|','')}{RST}")
    wait()

# ─────────────────────────────────────────────
# [8] SETTINGS/CFG (alias: cfg, settings)
# ─────────────────────────────────────────────
def menu_cfg():
    while True:
        title("SETTINGS  [cfg / settings]")
        info("Toggle pengaturan deobfuscation")
        pr()

        keys = list(SETTINGS.keys())
        for i, k in enumerate(keys):
            s = SETTINGS[k]
            state = f"{G}ON {RST}" if s["val"] else f"{R}OFF{RST}"
            print(f"  {DIM}[{i+1:2}]{RST} {state}  {k:<16} {DIM}{s['desc']}{RST}")

        pr()
        print(f"  {DIM}[ b]{RST} Kembali")
        print(f"  {DIM}[ r]{RST} Reset semua ke default")
        pr()

        choice = inp("Toggle nomor / b / r: ")
        if choice.lower() in ("b", ""): return
        if choice.lower() == "r":
            defaults = {"hookOp": True, "explore_funcs": True, "spyexeconly": False,
                        "minifier": True, "constants": False, "lua": False,
                        "roblox": False, "runtimelogs": False, "comments": False, "discord": True}
            for k, v in defaults.items():
                if k in SETTINGS: SETTINGS[k]["val"] = v
            ok("Reset ke default")
            time.sleep(0.6)
            continue

        try:
            idx = int(choice) - 1
            if 0 <= idx < len(keys):
                k = keys[idx]
                SETTINGS[k]["val"] = not SETTINGS[k]["val"]
                state = "ON" if SETTINGS[k]["val"] else "OFF"
                ok(f"{k} → {state}")
                time.sleep(0.4)
        except ValueError:
            err("Input tidak valid")
            time.sleep(0.5)

# ─────────────────────────────────────────────
# BESTCFG helper
# ─────────────────────────────────────────────
def apply_bestcfg(modes):
    cfg = {}
    for mode in modes:
        key = BESTCFG_ALIASES.get(mode, mode)
        diff = BESTCFG_VALUES.get(key)
        if not diff: return False, f"Mode tidak valid: {mode}"
        for setting, change in diff.items():
            cfg[setting] = cfg.get(setting, 0) + change

    changed = []
    for k, score in cfg.items():
        if k not in SETTINGS: continue
        new_val = score > 0
        if SETTINGS[k]["val"] != new_val:
            SETTINGS[k]["val"] = new_val
            changed.append(f"{'+ ' if new_val else '- '}{k}")

    return True, changed

def menu_bestcfg():
    title("BEST CONFIG")
    info("Pilih mode untuk auto-apply pengaturan terbaik")
    pr()

    print(f"  Mode tersedia:")
    for alias, key in BESTCFG_ALIASES.items():
        print(f"  {G}·{RST} {alias:<15} {DIM}(= {key}){RST}")
    for key in BESTCFG_VALUES:
        if key not in BESTCFG_ALIASES.values():
            print(f"  {G}·{RST} {key}")
    pr()

    modes_input = inp("Pilih mode (pisah koma, cth: speed,accuracy): ")
    if not modes_input: return

    modes = [m.strip().lower() for m in modes_input.split(",") if m.strip()]
    success, result = apply_bestcfg(modes)
    pr()

    if not success:
        err(result)
    elif not result:
        info("Tidak ada setting yang berubah")
    else:
        ok("Settings diupdate:")
        for r in result:
            print(f"    {r}")
    wait()

# ─────────────────────────────────────────────
# [9] DETECT OBFUSCATOR
# ─────────────────────────────────────────────
def menu_detect():
    title("DETECT OBFUSCATOR")
    info("Deteksi jenis obfuscator dari file Lua")
    pr()

    src = inp("Input file (.lua): ")
    if not src: return
    valid, msg = validate_lua(src)
    if not valid: err(msg); wait(); return

    src_p = Path(src).resolve()
    pr(); info("Mendeteksi..."); sep()
    code, stdout, stderr = node_run("detect.js", [src_p])
    sep(); pr()

    if code == 0 and stdout.startswith("OK|"):
        result = stdout.split("|", 1)[1]
        ok(f"Terdeteksi: {BOLD}{result}{RST}")
    else:
        err("Gagal deteksi")
        if stderr: print(f"  {DIM}{stderr}{RST}")
    wait()

# ─────────────────────────────────────────────
# [10] BATCH DEOBFUSCATE
# ─────────────────────────────────────────────
def menu_batch():
    title("BATCH DEOBFUSCATE")
    info("Deobfuscate semua .lua dalam folder")
    pr()

    folder = inp("Folder input: ")
    if not folder: return
    folder_p = Path(folder).resolve()
    if not folder_p.is_dir():
        err(f"Folder tidak ditemukan: {folder}"); wait(); return

    files = list(folder_p.glob("*.lua")) + list(folder_p.glob("*.luau"))
    if not files:
        err("Tidak ada file .lua/.luau"); wait(); return

    pr(); info(f"Ditemukan {len(files)} file:")
    for f in files: print(f"  {DIM}· {f.name}{RST}")
    pr()

    out_s = inp(f"Folder output [{folder_p}/output]: ")
    out_folder = Path(out_s).resolve() if out_s else folder_p / "output"
    out_folder.mkdir(parents=True, exist_ok=True)

    pr(); sep()
    ok_n = fail_n = 0

    for f in files:
        out_f = out_folder / (f.stem + "_deobf.lua")
        info(f"Processing: {f.name}")
        code = subprocess.run(
            ["node", str(CORE / "main.js"), str(f), str(out_f)],
            cwd=str(BASE), capture_output=True
        ).returncode
        if code == 0:
            ok(f"  → {out_f.name}"); ok_n += 1
        else:
            err(f"  → Gagal"); fail_n += 1
        pr()

    sep(); pr()
    ok(f"Berhasil: {ok_n}/{len(files)}")
    if fail_n: err(f"Gagal: {fail_n}/{len(files)}")
    ok(f"Output folder: {out_folder}")
    wait()

# ─────────────────────────────────────────────
# INFO
# ─────────────────────────────────────────────
def menu_info():
    title("INFO SISTEM")

    try:
        nv = subprocess.run(["node","--version"], capture_output=True, text=True).stdout.strip()
    except: nv = "N/A"
    try:
        npmv = subprocess.run(["npm","--version"], capture_output=True, text=True).stdout.strip()
    except: npmv = "N/A"

    js_files = list((BASE / "src").rglob("*.js"))
    lua_files = list((BASE / "lua").rglob("*.lua"))

    print(f"  {C}Node.js  :{RST} {nv}")
    print(f"  {C}npm      :{RST} {npmv}")
    print(f"  {C}Deps     :{RST} {'✓' if NODE_MODULES.exists() else '✗ Belum install'}")
    print(f"  {C}JS files :{RST} {len(js_files)}")
    print(f"  {C}Lua refs :{RST} {len(lua_files)}")
    print(f"  {C}Base dir :{RST} {BASE}")
    pr()

    print(f"  {BOLD}Fitur:{RST}")
    cmds = [
        ("deobf",     "Prometheus deobfuscate"),
        ("bf/coolify","Beautify Lua"),
        ("minify",    "Minify Lua"),
        ("noluaobf",  "LuaObfuscator deobf"),
        ("wearedevs", "WeAreDevs obfuscate"),
        ("http/wget", "HTTP GET request"),
        ("bp",        "Bypass shortlink"),
        ("cfg",       "Manage settings"),
        ("bestcfg",   "Auto best settings"),
        ("detect",    "Deteksi obfuscator"),
        ("batch",     "Batch deobfuscate"),
    ]
    for alias, desc in cmds:
        print(f"  {DIM}·{RST} {G}{alias:<16}{RST} {DIM}{desc}{RST}")

    wait()

# ─────────────────────────────────────────────
# MAIN MENU
# ─────────────────────────────────────────────
def main():
    ensure_deps()

    while True:
        title()
        print(f"  {BOLD}MENU UTAMA{RST}\n")
        print(f"  {G}[1]{RST} Deobfuscate          {DIM}deobf / promdeobf / msecdeobf{RST}")
        print(f"  {G}[2]{RST} Beautify Lua          {DIM}bf / coolify{RST}")
        print(f"  {G}[3]{RST} Minify Lua")
        print(f"  {G}[4]{RST} LuaObfuscator Deobf   {DIM}noluaobf{RST}")
        print(f"  {G}[5]{RST} WeAreDevs Obfuscate   {DIM}wearedevs{RST}")
        print(f"  {G}[6]{RST} HTTP GET              {DIM}http / httpget / wget{RST}")
        print(f"  {G}[7]{RST} Bypass Link           {DIM}bp{RST}")
        print(f"  {G}[8]{RST} Settings              {DIM}cfg / settings{RST}")
        print(f"  {G}[9]{RST} Best Config           {DIM}bestcfg{RST}")
        print(f"  {G}[a]{RST} Deteksi Obfuscator")
        print(f"  {G}[b]{RST} Batch Deobfuscate")
        print(f"  {G}[i]{RST} Info Sistem")
        print(f"  {R}[0]{RST} Keluar")
        pr()
        choice = inp("Pilih: ").lower()

        m = {
            "1": menu_deobf,
            "2": menu_beautify,
            "3": menu_minify,
            "4": menu_luaobf,
            "5": menu_wrd,
            "6": menu_httpget,
            "7": menu_bypass,
            "8": menu_cfg,
            "9": menu_bestcfg,
            "a": menu_detect,
            "b": menu_batch,
            "i": menu_info,
        }

        if choice == "0":
            title(); print(f"  {C}Bye!{RST}\n"); sys.exit(0)
        elif choice in m:
            m[choice]()
        else:
            err("Pilihan tidak valid"); time.sleep(0.5)

if __name__ == "__main__":
    main()
