const fs = require("fs")

const inp = process.argv[2]
const out = process.argv[3]

if (!inp || !out) {
    console.error("Usage: node wearedevs.js <input> <output>")
    process.exit(1)
}

;(async () => {
    try {
        const src = fs.readFileSync(inp, "utf8")
        const start = performance.now()

        const res = await fetch("https://wearedevs.net/api/obfuscate", {
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ script: src }),
            method: "POST"
        })
        const json = await res.json()

        if (!json.success) {
            console.error("ERR|" + JSON.stringify(json))
            process.exit(1)
        }

        fs.writeFileSync(out, json.obfuscated)
        console.log(`OK|${Math.floor(performance.now() - start)}`)
    } catch (err) {
        console.error("ERR|" + err.message)
        process.exit(1)
    }
})()
