const fs = require("fs")

const url = process.argv[2]
const out = process.argv[3]

if (!url || !out) {
    console.error("Usage: node httpget.js <url> <output>")
    process.exit(1)
}

;(async () => {
    try {
        const start = performance.now()
        const res = await fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0"
            }
        })

        if (!res.ok) {
            console.error(`ERR|${res.status} ${res.statusText}`)
            process.exit(1)
        }

        const text = await res.text()
        fs.writeFileSync(out, text)
        console.log(`OK|${Math.floor(performance.now() - start)}|${Buffer.byteLength(text, "utf8")}`)
    } catch (err) {
        console.error("ERR|" + err.message)
        process.exit(1)
    }
})()
